******************************************************************************

    a simple DLL to read and write the PulseWaves format version 0.3 rev 5

******************************************************************************

The example code "testDLLwrite.cpp" shows how to use the PulseWaves DLL to
write full waveform LiDAR data into the PulseWaves format.

The example code "testDLLwrite.cpp" shows how to use the PulseWaves DLL to
write full waveform LiDAR data into the PulseWaves format.

The example code "testDLLerror.cpp" tries out various ways of creating error
codes by miss-using the PulseWaves DLL when attempting to write PulseWaves.

This is a reasonably mature 0.s release of the DLL and while the PulseWaves
format may still change, these changes will be small. So once you are able
to use this version of the DLL it will only need trivial modifications in
your export and import code to write and read full waveforms from and to the
soon to be finalized 1.0 PulseWaves release.

******************************************************************************

martin@rapidlasso.com

http://rapidlasso.com - fast tools to catch reality
