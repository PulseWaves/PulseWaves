******************************************************************************

     a simple DLL to write the PulseWaves format version 0.1 (pre-alpha)

******************************************************************************

The example code "testDLL.cpp" shows how to use the PulseWaves DLL to write
full waveform LiDAR data into the PulseWaves format.

This is the very first 0.1 release of the DLL and the PulseWaves format is
still expected to change. However, these changes will be small so once you
are able to use this version of the DLL it will only need minor modifications
in your code to write full waveforms in the 1.0 PulseWaves release.

******************************************************************************

martin.isenburg@gmail.com

http://rapidlasso.com - fast tools to catch reality