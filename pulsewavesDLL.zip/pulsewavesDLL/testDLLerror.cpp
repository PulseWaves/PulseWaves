/*
===============================================================================

  FILE:  testDLLerror.cpp
  
  CONTENTS:
  
    This is a error test program for the pulsewaves DLL.

  PROGRAMMERS:
  
    martin.isenburg@rapidlasso.com  -  http://rapidlasso.com
  
  COPYRIGHT:
  
    (c) 2007-2013, martin isenburg, rapidlasso - fast tools to catch reality

    This is free software; you can redistribute and/or modify it under the
    terms of the GNU Lesser General Licence as published by the Free Software
    Foundation. See the COPYING file for more information.

    This software is distributed WITHOUT ANY WARRANTY and without even the
    implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  
  CHANGE HISTORY:
  
    22 February 2013 -- created with Wolfgang at ARA to get the DLL into Pascal
  
===============================================================================
*/

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "pulsewaves_dll.h"

static void usage(bool wait=false)
{
  fprintf(stderr,"usage:\n");
  fprintf(stderr,"testDLLerror -h\n");
  fprintf(stderr,"testDLLerror -v\n");
  if (wait)
  {
    fprintf(stderr,"<press ENTER>\n");
    getc(stdin);
  }
  exit(1);
}

static void dll_error(pulsewaves_POINTER pulsewaves)
{
  if (pulsewaves != 0)
  {
    pulsewaves_CHAR* error;
    if (pulsewaves_get_error(pulsewaves, &error))
    {
      fprintf(stderr,"DLL ERROR: getting error messages\n");
    }
    fprintf(stderr,"DLL ERROR MESSAGE: %s\n", error);
  }
}

static void byebye(bool error=false, bool wait=false, pulsewaves_POINTER pulsewaves=0)
{
  if (error)
  {  
    dll_error(pulsewaves);
  }
  if (wait)
  {
    fprintf(stderr,"<press ENTER>\n");
    getc(stdin);
  }
  exit(error);
}

static double taketime()
{
  return (double)(clock())/CLOCKS_PER_SEC;
}

#define DESCRIPTOR_ONLY_OUTGOING                      1
#define DESCRIPTOR_ONE_LOW_VARYING                    2
#define DESCRIPTOR_TWO_LOW_VARYING                    3
#define DESCRIPTOR_THREE_LOW_VARYING                  4
#define DESCRIPTOR_ONE_HIGH_VARYING                   5
#define DESCRIPTOR_ONE_LOW_VARYING_ONE_HIGH_VARYING   6
#define DESCRIPTOR_TWO_LOW_VARYING_ONE_HIGH_VARYING   7
#define DESCRIPTOR_THREE_LOW_VARYING_ONE_HIGH_VARYING 8
#define DESCRIPTOR_X_LOW_VARYING_X_HIGH_VARYING       9

int main(int argc, char *argv[])
{
  int i;
  bool verbose = false;
  const char* file_name = "error.pls";

  // load pulsewaves DLL

  if (pulsewaves_load_dll())
  {
    fprintf(stderr,"DLL ERROR: loading pulsewaves DLL\n");
    byebye(true, argc==1);
  }

  // get version of pulsewaves DLL

  pulsewaves_U8 version_major;
  pulsewaves_U8 version_minor;
  pulsewaves_U16 version_revision;
  pulsewaves_U32 version_build;

  if (pulsewaves_get_version(&version_major, &version_minor, &version_revision, &version_build))
  {
    fprintf(stderr,"DLL ERROR: getting pulsewaves DLL version number\n");
    byebye(true, argc==1);
  }

  for (i = 1; i < argc; i++)
  {
    if (strcmp(argv[i],"-h") == 0 || strcmp(argv[i],"-help") == 0)
    {
      fprintf(stderr, "testDLLwrite of PULSEtools (by martin.isenburg@rapidlasso.com) version: %d.%d r%d (build %d)\n", version_major, version_minor, version_revision, version_build);
      usage();
    }
    else if (strcmp(argv[i],"-version") == 0)
    {
      fprintf(stderr, "testDLLwrite of PULSEtools (by martin.isenburg@rapidlasso.com) version: %d.%d r%d (build %d)\n", version_major, version_minor, version_revision, version_build);
      byebye();
    }
    else if (strcmp(argv[i],"-v") == 0 || strcmp(argv[i],"-verbose") == 0)
    {
      verbose = true;
    }
    else
    {
      fprintf(stderr, "ERROR: cannot understand argument '%s'\n", argv[i]);
      usage();
    }
  }

  if (verbose)
  {
    fprintf(stderr,"pulsewaves DLL version: %d.%d r%d (build %d)\n", version_major, version_minor, version_revision, version_build);
    fprintf(stderr,"writing to error.pls & error.wvs\n");
  }

  // create object in pulsewaves DLL

  pulsewaves_POINTER pulsewaves;
  if (pulsewaves_create(&pulsewaves))
  {
    fprintf(stderr,"DLL ERROR: creating pulsewaves object\n");
    byebye(true, argc==1);
  }

  // populate header

  pulsewaves_header header;

  // get the default header (with errors)

  if (pulsewaves_header_get(0, &header))
  {
    fprintf(stderr,"stupidity: handing zero pulsewaves pointer to pulsewaves_header_get()\n");
    fprintf(stderr,"DLL ERROR: getting default pulsewaves header\n");
    dll_error(pulsewaves);
  }

  if (pulsewaves_header_get(pulsewaves, 0))
  {
    fprintf(stderr,"stupidity: handing zero header pointer to pulsewaves_header_get()\n");
    fprintf(stderr,"DLL ERROR: getting default pulsewaves header\n");
    dll_error(pulsewaves);
  }

  // get the default header

  if (pulsewaves_header_get(pulsewaves, &header))
  {
    fprintf(stderr,"DLL ERROR: getting default pulsewaves header\n");
    byebye(true, argc==1, pulsewaves);
  }

  header.file_source_ID = 4711;
  sprintf(header.system_identifier, "testDLLerror prototype tester");
  sprintf(header.generating_software, "PulseWaves DLL version %d.%d revision %d (%d)", version_major, version_minor, version_revision, version_build);
  header.file_creation_day = 222;
  header.file_creation_year = 2012;
  header.number_of_pulses = 12;

  // set the default header (with errors)

  if (pulsewaves_header_set(0, &header))
  {
    fprintf(stderr,"stupidity: handing zero pulsewaves pointer to pulsewaves_header_set()\n");
    fprintf(stderr,"DLL ERROR: setting pulsewaves header\n");
    dll_error(pulsewaves);
  }

  if (pulsewaves_header_set(pulsewaves, 0))
  {
    fprintf(stderr,"stupidity: handing zero header pointer to pulsewaves_header_set()\n");
    fprintf(stderr,"DLL ERROR: setting pulsewaves header\n");
    dll_error(pulsewaves);
  }

  // set the header

  if (pulsewaves_header_set(pulsewaves, &header))
  {
    fprintf(stderr,"DLL ERROR: setting pulsewaves header\n");
    byebye(true, argc==1, pulsewaves);
  }

  // populate the scanner
  
  pulsewaves_scanner scanner;

  // get default scanner settings (with errors)

  if (pulsewaves_header_get_scanner(0, &scanner, 0))
  {
    fprintf(stderr,"stupidity: handing zero pulsewaves pointer to pulsewaves_header_get_scanner()\n");
    fprintf(stderr,"DLL ERROR: getting default scanner settings\n");
    dll_error(pulsewaves);
  }

  if (pulsewaves_header_get_scanner(pulsewaves, 0, 0))
  {
    fprintf(stderr,"stupidity: handing zero scanner pointer to pulsewaves_header_get_scanner()\n");
    fprintf(stderr,"DLL ERROR: getting default scanner settings\n");
    dll_error(pulsewaves);
  }

  // get default scanner settings

  if (pulsewaves_header_get_scanner(pulsewaves, &scanner, 0))
  {
    fprintf(stderr,"DLL ERROR: getting default scanner settings\n");
    byebye(true, argc==1, pulsewaves);
  }

  strncpy(scanner.instrument, "RIEGL Q560", PULSEWAVESDLL_DESCRIPTION_SIZE);
  strncpy(scanner.serial, "RMS-2011-00232-13", PULSEWAVESDLL_DESCRIPTION_SIZE);
  scanner.wave_length = 1064.0f;                  // [nanometer]
  scanner.outgoing_pulse_width = 4.0f;            // [nanoseconds]
  scanner.scan_pattern = 2;                       // 0 = undefined, 1 = oscillating, 2 = line, 3 = conic
  scanner.number_of_mirror_facets = 4;
  scanner.scan_frequency = 160.0f;                // [hertz]
  scanner.scan_angle_min = -30.0f;                // [degree]
  scanner.scan_angle_max = +30.0f;                // [degree]
  scanner.pulse_frequency = 240.0f;               // [kilohertz]
  scanner.beam_diameter_at_exit_aperture = 10.0f; // [millimeters]
  scanner.beam_divergence = 0.3f;                 // [milliradians]
  scanner.minimal_range = 100.0f;                 // [meters]
  scanner.maximal_range = 4200.0f;                // [meters]
  strncpy(scanner.description, "scanner description generated by testDLLwrite.exe", PULSEWAVESDLL_DESCRIPTION_SIZE);

  // add scanner with index 1 to the header (with errors)

  if (pulsewaves_header_add_scanner(0, &scanner, 1))
  {
    fprintf(stderr,"stupidity: handing zero pulsewaves pointer to pulsewaves_header_add_scanner()\n");
    fprintf(stderr,"DLL ERROR: adding scanner to header\n");
    dll_error(pulsewaves);
  }

  if (pulsewaves_header_add_scanner(pulsewaves, 0, 1))
  {
    fprintf(stderr,"stupidity: handing zero scanner pointer to pulsewaves_header_add_scanner()\n");
    fprintf(stderr,"DLL ERROR: adding scanner to header\n");
    dll_error(pulsewaves);
  }

  // add scanner with index 1 to the header 

  if (pulsewaves_header_add_scanner(pulsewaves, &scanner, 1))
  {
    fprintf(stderr,"DLL ERROR: adding scanner to header\n");
    byebye(true, argc==1, pulsewaves);
  }

  // create one pulsedescriptor (pulsecomposition + pulsesamplings)

  pulsewaves_pulsecomposition_struct composition;
  pulsewaves_pulsesampling_struct samplings[2];

  // create pulsedescriptor for pulses with one returning waveform

  composition.optical_center_to_anchor_point = 0;            // the duration between optical center and anchor point is zero
  composition.number_of_extra_waves_bytes = 0; 
  composition.number_of_samplings = 2;                       // one outgoing only, none returning
  composition.sample_units = 1.0f;                           // [nanoseconds]
  composition.scanner_index = 1;                             // the pulse was recorded by the scanner with index 1
  memset(composition.description, 0, PULSEWAVESDLL_DESCRIPTION_SIZE);
  strncpy(composition.description, "one outgoing, one returning", PULSEWAVESDLL_DESCRIPTION_SIZE);

  samplings[0].type = PULSEWAVESDLL_OUTGOING;
  samplings[0].channel = 0;
  samplings[0].bits_for_duration_from_anchor = 0;            // the anchor point is the optical center. this is when the outgoing waveform starts.
  samplings[0].scale_for_duration_from_anchor = 1.0f;        // not-applicable, but needs proper initialization
  samplings[0].offset_for_duration_from_anchor = 0.0f;       // not-applicable, but needs proper initialization
  samplings[0].bits_for_number_of_segments = 0;              // the number of segments is fixed (i.e. there is just one)
  samplings[0].bits_for_number_of_samples = 0;               // the number of samples is fixed (i.e. it is always 24)
  samplings[0].number_of_segments = 1;                       // the number of segments per sampling is always 1
  samplings[0].number_of_samples = 24;                       // the number of samples per segment is always 24
  samplings[0].bits_per_sample = 8;                          // the number of bits per sample is always 8
  samplings[0].lookup_table_index = PULSEWAVESDLL_UNDEFINED; // the index to the optional lookup table translating sample values to physical measurements
  samplings[0].sample_units = 1.0f;                          // [nanoseconds]
  memset(samplings[0].description, 0, PULSEWAVESDLL_DESCRIPTION_SIZE);
  strncpy(samplings[0].description, "outgoing, 1 segment, 24 samples, 8 bits", PULSEWAVESDLL_DESCRIPTION_SIZE);

  samplings[1].type = PULSEWAVESDLL_RETURNING;
  samplings[1].channel = 0;
  samplings[1].bits_for_duration_from_anchor = 16;           // the start of each waveform segment is specified with 16 bits (in sampling units) 
  samplings[1].scale_for_duration_from_anchor = 0.1f;        // the 16 bit duration is quantized and must first be multiplied with 0.1f ...
  samplings[1].offset_for_duration_from_anchor = 8192.0f;    // ... and then offset by +8192.0f to get the actual duration value
  samplings[1].bits_for_number_of_segments = 0;              // the number of segments is fixed (i.e. there is exactly one)
  samplings[1].bits_for_number_of_samples = 8;               // the number of samples per segment is specified per segment with 8 bits
  samplings[1].number_of_segments = 1;                       // the number of segments per sampling is always 1
  samplings[1].number_of_samples = 0;                        // the number of samples per segment varies
  samplings[1].bits_per_sample = 8;                          // the number of bits per sample is always 8
  samplings[1].lookup_table_index = PULSEWAVESDLL_UNDEFINED; // the index to the optional lookup table translating sample values to physical measurements
  samplings[1].sample_units = 1.0f;                          // [nanoseconds]
  memset(samplings[1].description, 0, PULSEWAVESDLL_DESCRIPTION_SIZE);
  strncpy(samplings[1].description, "returning, 1 segment, varying samples, 8 bits", PULSEWAVESDLL_DESCRIPTION_SIZE);

  // add pulsedescriptor with index 1 to the header (with errors)

  if (pulsewaves_header_add_pulsedescriptor(0, &composition, samplings, 1))
  {
    fprintf(stderr,"stupidity: handing zero pulsewaves pointer to pulsewaves_header_add_pulsedescriptor()\n");
    fprintf(stderr,"DLL ERROR: adding pulsedescriptor to header\n");
    dll_error(pulsewaves);
  }

  if (pulsewaves_header_add_pulsedescriptor(pulsewaves, 0, samplings, 1))
  {
    fprintf(stderr,"stupidity: handing zero composition pointer to pulsewaves_header_add_pulsedescriptor()\n");
    fprintf(stderr,"DLL ERROR: adding pulsedescriptor to header\n");
    dll_error(pulsewaves);
  }

  if (pulsewaves_header_add_pulsedescriptor(pulsewaves, &composition, 0, 1))
  {
    fprintf(stderr,"stupidity: handing zero samplings pointer to pulsewaves_header_add_pulsedescriptor()\n");
    fprintf(stderr,"DLL ERROR: adding pulsedescriptor to header\n");
    dll_error(pulsewaves);
  }

  samplings[0].scale_for_duration_from_anchor = 0.0f;        // not-applicable, but needs proper initialization
  if (pulsewaves_header_add_pulsedescriptor(pulsewaves, &composition, samplings, 1))
  {
    fprintf(stderr,"stupidity: scale for duration from anchor set to zero\n");
    fprintf(stderr,"DLL ERROR: adding pulsedescriptor to header\n");
    dll_error(pulsewaves);
  }
  samplings[0].scale_for_duration_from_anchor = 1.0f;        // not-applicable, but needs proper initialization

  samplings[0].bits_for_duration_from_anchor = 7;           // the start of each waveform segment is specified with 16 bits (in sampling units) 
  if (pulsewaves_header_add_pulsedescriptor(pulsewaves, &composition, samplings, 1))
  {
    fprintf(stderr,"stupidity: bits for duration from anchor set to seven\n");
    fprintf(stderr,"DLL ERROR: adding pulsedescriptor to header\n");
    dll_error(pulsewaves);
  }
  samplings[0].bits_for_duration_from_anchor = 0;           // the start of each waveform segment is specified with 16 bits (in sampling units) 

  samplings[0].bits_for_number_of_segments = 8;              // the number of segments is fixed (i.e. there is just one)
  if (pulsewaves_header_add_pulsedescriptor(pulsewaves, &composition, samplings, 1))
  {
    fprintf(stderr,"stupidity: bits_for_number_of_segments is 8 and number_of_segments is 1\n");
    fprintf(stderr,"DLL ERROR: adding pulsedescriptor to header\n");
    dll_error(pulsewaves);
  }
  samplings[0].bits_for_number_of_segments = 0;              // the number of segments is fixed (i.e. there is just one)

  samplings[0].bits_for_number_of_samples = 8;               // the number of samples is fixed (i.e. it is always 24)
  if (pulsewaves_header_add_pulsedescriptor(pulsewaves, &composition, samplings, 1))
  {
    fprintf(stderr,"stupidity: bits_for_number_of_samples is 8 and number_of_samples is 24\n");
    fprintf(stderr,"DLL ERROR: adding pulsedescriptor to header\n");
    dll_error(pulsewaves);
  }
  samplings[0].bits_for_number_of_samples = 0;               // the number of samples is fixed (i.e. it is always 24)


  // add pulsedescriptor with index 1 to the header

  if (pulsewaves_header_add_pulsedescriptor(pulsewaves, &composition, samplings, 1))
  {
    fprintf(stderr,"DLL ERROR: adding pulsedescriptor to header\n");
    byebye(true, argc==1, pulsewaves);
  }

  // open the writer (with errors)

  if (pulsewaves_writer_open(0, file_name, 0))
  {
    fprintf(stderr,"stupidity: handing zero pulsewaves pointer to pulsewaves_writer_open()\n");
    fprintf(stderr,"DLL ERROR: opening pulsewaves writer\n");
    dll_error(pulsewaves);
  }

  if (pulsewaves_writer_open(pulsewaves, 0, 0))
  {
    fprintf(stderr,"stupidity: handing zero file_name pointer to pulsewaves_writer_open()\n");
    fprintf(stderr,"DLL ERROR: opening pulsewaves writer\n");
    dll_error(pulsewaves);
  }

  // open the writer

  if (pulsewaves_writer_open(pulsewaves, file_name, 0))
  {
    fprintf(stderr,"DLL ERROR: opening pulsewaves writer\n");
    byebye(true, argc==1, pulsewaves);
  }

  // setup pulse

  pulsewaves_pulse_struct pulse;

  pulse.T = 129863735377; // to get Standard GPS time in seconds, scale by 1e-6 and add 1e9 seconds

  pulse.anchor[0] = 235006.189; 
  pulse.anchor[1] = 800051.276;
  pulse.anchor[2] = 1261.177; 
  
  pulse.target[0] = 235006.189 + 1000.0 * 0.0422858574893;
  pulse.target[1] = 800051.276 - 1000.0 * 0.0139114190461;
  pulse.target[2] = 1261.177 - 1000.0 * 0.143093129736;

  pulse.first_returning_sample = 8213;
  pulse.last_returning_sample = 8251;
  pulse.descriptor_index = 1; // outgoing + returning
  pulse.edge_of_scan_line = 0;
  pulse.scan_direction = 0;
  pulse.mirror_facet = 2;
  pulse.intensity = 0;
  pulse.classification = 0;

  // write pulse (with error)

  if (pulsewaves_writer_write_pulse(0, &pulse))
  {
    fprintf(stderr,"stupidity: handing zero pulsewaves pointer to pulsewaves_writer_write_pulse()\n");
    fprintf(stderr,"DLL ERROR: writing pulse\n");
    dll_error(pulsewaves);
  }

  if (pulsewaves_writer_write_pulse(pulsewaves, 0))
  {
    fprintf(stderr,"stupidity: handing zero pulse pointer to pulsewaves_writer_write_pulse()\n");
    fprintf(stderr,"DLL ERROR: writing pulse\n");
    dll_error(pulsewaves);
  }

  // write pulse

  if (pulsewaves_writer_write_pulse(pulsewaves, &pulse))
  {
    fprintf(stderr,"DLL ERROR: writing pulse\n");
    byebye(true, argc==1, pulsewaves);
  }

  // setup waves

  pulsewaves_wavessampling wavessampling[2];

  // setup wavessampling[0] (outgoing, 1 segment, 24 samples, 8 bits)

  pulsewaves_I32 outgoing_num_samples[1] = { 24 };
  pulsewaves_F32 outgoing_durations[1] = { 0.0f };
  pulsewaves_U8 outgoing_samples_segment[24] = { 2,2,2,2,3,9,19,34,57,91,143,167,127,82,55,23,9,6,3,2,2,2,2,2 } ;
  pulsewaves_U8* outgoing_samples[1];
  outgoing_samples[0] = outgoing_samples_segment;

  wavessampling[0].num_segments = 1;
  wavessampling[0].num_samples = outgoing_num_samples;
  wavessampling[0].durations = outgoing_durations;
  wavessampling[0].samples = outgoing_samples;

  // setup wavessampling[1] (returning, 1 segment, 39 samples, 8 bits)

  pulsewaves_I32 returning_num_samples[1] = { 39 };
  pulsewaves_F32 returning_durations[1] = { 8212.7534f };
  pulsewaves_U8 returning_samples_segment[39] = { 2,2,2,2,2,2,2,2,2,2,2,2,5,9,22,39,57,78,101,127,138,151,120,101,88,56,43,33,21,14,9,6,4,3,2,2,2,2,2 } ;
  pulsewaves_U8* returning_samples[1];
  returning_samples[0] = returning_samples_segment;

  wavessampling[1].num_segments = 1;
  wavessampling[1].num_samples = returning_num_samples;
  wavessampling[1].durations = returning_durations;
  wavessampling[1].samples = returning_samples;

  // write waves (with error)

  if (pulsewaves_writer_write_waves(0, wavessampling, 2))
  {
    fprintf(stderr,"stupidity: handing zero pulsewaves pointer to pulsewaves_writer_write_waves()\n");
    fprintf(stderr,"DLL ERROR: writing waves\n");
    dll_error(pulsewaves);
  }

  if (pulsewaves_writer_write_waves(pulsewaves, 0, 2))
  {
    fprintf(stderr,"stupidity: handing zero wavessampling pointer to pulsewaves_writer_write_waves()\n");
    fprintf(stderr,"DLL ERROR: writing waves\n");
    dll_error(pulsewaves);
  }

  if (pulsewaves_writer_write_waves(pulsewaves, wavessampling, 1))
  {
    fprintf(stderr,"stupidity: handing wrong number_of_wavessamplings to pulsewaves_writer_write_waves()\n");
    fprintf(stderr,"DLL ERROR: writing waves\n");
    dll_error(pulsewaves);
  }

  // write waves

  if (pulsewaves_writer_write_waves(pulsewaves, wavessampling, 2))
  {
    fprintf(stderr,"DLL ERROR: writing waves\n");
    byebye(true, argc==1, pulsewaves);
  }

  // close the writer

  if (pulsewaves_writer_close(pulsewaves))
  {
    fprintf(stderr,"DLL ERROR: closing pulsewaves writer\n");
    byebye(true, argc==1, pulsewaves);
  }

  // destroy object in pulsewaves DLL

  if (pulsewaves_destroy(pulsewaves))
  {
    fprintf(stderr,"DLL ERROR: destroying pulsewaves object\n");
    byebye(true, argc==1);
  }

  return 0;
}
