/*
===============================================================================

  FILE:  testDLLread.cpp
  
  CONTENTS:
  
    This is a test program for reading with the pulsewaves DLL.

  PROGRAMMERS:
  
    martin.isenburg@rapidlasso.com  -  http://rapidlasso.com
  
  COPYRIGHT:
  
    (c) 2007-2013, martin isenburg, rapidlasso - fast tools to catch reality

    This is free software; you can redistribute and/or modify it under the
    terms of the GNU Lesser General Licence as published by the Free Software
    Foundation. See the COPYING file for more information.

    This software is distributed WITHOUT ANY WARRANTY and without even the
    implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  
  CHANGE HISTORY:
  
    30 October 2012 -- created after the cloud cover moved back across Glenelg
  
===============================================================================
*/

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "pulsewaves_dll.h"

static void usage(bool wait=false)
{
  fprintf(stderr,"usage:\n");
  fprintf(stderr,"testDLLread -h\n");
  fprintf(stderr,"testDLLread -v\n");
  if (wait)
  {
    fprintf(stderr,"<press ENTER>\n");
    getc(stdin);
  }
  exit(1);
}

static void dll_error(pulsewaves_POINTER pulsewaves)
{
  if (pulsewaves != 0)
  {
    pulsewaves_CHAR* error;
    if (pulsewaves_get_error(pulsewaves, &error))
    {
      fprintf(stderr,"DLL ERROR: getting error messages\n");
    }
    fprintf(stderr,"DLL ERROR MESSAGE: %s\n", error);
  }
}

static void byebye(bool error=false, bool wait=false, pulsewaves_POINTER pulsewaves=0)
{
  if (error)
  {  
    dll_error(pulsewaves);
  }
  if (wait)
  {
    fprintf(stderr,"<press ENTER>\n");
    getc(stdin);
  }
  exit(error);
}

static double taketime()
{
  return (double)(clock())/CLOCKS_PER_SEC;
}

int main(int argc, char *argv[])
{
  int i;
  bool verbose = false;
  bool compress = false;
  const char* file_name = "test.pls";

  // load pulsewaves DLL

  if (pulsewaves_load_dll())
  {
    fprintf(stderr,"ERROR: loading pulsewaves DLL\n");
    byebye(true, argc==1);
  }

  // get version of pulsewaves DLL

  pulsewaves_U8 version_major;
  pulsewaves_U8 version_minor;
  pulsewaves_U16 version_revision;
  pulsewaves_U32 version_build;

  if (pulsewaves_get_version(&version_major, &version_minor, &version_revision, &version_build))
  {
    fprintf(stderr,"ERROR: getting pulsewaves DLL version number\n");
    byebye(true, argc==1);
  }

  for (i = 1; i < argc; i++)
  {
    if (strcmp(argv[i],"-h") == 0 || strcmp(argv[i],"-help") == 0)
    {
      fprintf(stderr, "testDLLread of PULSEtools (by martin.isenburg@rapidlasso.com) version: %d.%d r%d (build %d)\n", version_major, version_minor, version_revision, version_build);
      usage();
    }
    else if (strcmp(argv[i],"-version") == 0)
    {
      fprintf(stderr, "testDLLread of PULSEtools (by martin.isenburg@rapidlasso.com) version: %d.%d r%d (build %d)\n", version_major, version_minor, version_revision, version_build);
      byebye();
    }
    else if (strcmp(argv[i],"-v") == 0 || strcmp(argv[i],"-verbose") == 0)
    {
      verbose = true;
    }
    else if (strcmp(argv[i],"-i") == 0)
    {
      if ((i+1) >= argc)
      {
        fprintf(stderr,"ERROR: '%s' needs 1 argument: file_name\n", argv[i]);
        byebye(true);
      }
      i++;
      file_name = argv[i];
    }
    else
    {
      fprintf(stderr, "ERROR: cannot understand argument '%s'\n", argv[i]);
      usage(true);
    }
  }

  if (verbose)
  {
    fprintf(stderr,"pulsewaves DLL version: %d.%d r%d (build %d)\n", version_major, version_minor, version_revision, version_build);
    fprintf(stderr,"reading from '%s'\n", file_name);
  }

  // create object in pulsewaves DLL

  pulsewaves_POINTER pulsewaves;
  if (pulsewaves_create(&pulsewaves))
  {
    fprintf(stderr,"DLL ERROR: creating pulsewaves object\n");
    byebye(true, argc==1);
  }

  // open the reader

  pulsewaves_BOOL is_compressed;

  if (pulsewaves_reader_open(pulsewaves, file_name, &is_compressed))
  {
    fprintf(stderr,"DLL ERROR: opening pulsewaves reader for '%s'\n", file_name);
    byebye(true, argc==1, pulsewaves);
  }

  // get the header

  pulsewaves_header header;

  if (pulsewaves_header_get(pulsewaves, &header))
  {
    fprintf(stderr,"DLL ERROR: getting pulsewaves header from '%s'\n", file_name);
    byebye(true, argc==1, pulsewaves);
  }

  // report how many pulses the file has

#ifdef _WIN32
  fprintf(stderr,"file '%s' contains %I64d pulses\n", file_name, header.number_of_pulses);
#else
  fprintf(stderr,"file '%s' contains %lld pulses\n", file_name, header.number_of_pulses);
#endif

  // read the pulses and their waves

  pulsewaves_pulse_struct pulse;
  pulsewaves_wavessampling* wavessampling = 0;
  pulsewaves_U32 number_of_wavessamplings = 0;

  int count = 0;

  while (count < header.number_of_pulses)
  {
    // get the pulse

    if (pulsewaves_reader_read_pulse(pulsewaves, &pulse))
    {
      fprintf(stderr,"DLL ERROR: reading pulse %d from '%s'\n", count, file_name);
      byebye(true, argc==1, pulsewaves);
    }

    // get the pulse descriptor (optional)

    pulsewaves_pulsecomposition_struct* pulsecomposition = 0;
    pulsewaves_pulsesampling_struct* pulsesamplings = 0;

    if (pulsewaves_header_get_pulsedescriptor(pulsewaves, &pulsecomposition, &pulsesamplings, pulse.descriptor_index))
    {
      fprintf(stderr,"DLL ERROR: getting pulsedescriptor %d from '%s'\n", pulse.descriptor_index, file_name);
      byebye(true, argc==1, pulsewaves);
    }

    // read the waves

    if (pulsewaves_reader_read_waves(pulsewaves, &wavessampling, &number_of_wavessamplings))
    {
      fprintf(stderr,"DLL ERROR: reading waves %d from '%s'\n", count, file_name);
      byebye(true, argc==1, pulsewaves);
    }
    count++;
  }

  fprintf(stderr,"successfully read all %d pulses\n", count);

  // close the writer

  if (pulsewaves_reader_close(pulsewaves))
  {
    fprintf(stderr,"DLL ERROR: closing pulsewaves reader\n");
    byebye(true, argc==1, pulsewaves);
  }

  // destroy object in pulsewaves DLL

  if (pulsewaves_destroy(pulsewaves))
  {
    fprintf(stderr,"DLL ERROR: destroying pulsewaves object\n");
    byebye(true, argc==1);
  }

  return 0;
}
