/*
===============================================================================

  FILE:  testDLLwrite.cpp
  
  CONTENTS:
  
    This is a test program for the pulsewaves DLL.

  PROGRAMMERS:
  
    martin.isenburg@rapidlasso.com  -  http://rapidlasso.com
  
  COPYRIGHT:
  
    (c) 2007-2013, martin isenburg, rapidlasso - fast tools to catch reality

    This is free software; you can redistribute and/or modify it under the
    terms of the GNU Lesser General Licence as published by the Free Software
    Foundation. See the COPYING file for more information.

    This software is distributed WITHOUT ANY WARRANTY and without even the
    implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  
  CHANGE HISTORY:
  
    6 September 2012 -- created in the RailJet 260 between Vienna and Munich
  
===============================================================================
*/

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "pulsewaves_dll.h"

static void usage(bool wait=false)
{
  fprintf(stderr,"usage:\n");
  fprintf(stderr,"testDLLwrite -h\n");
  fprintf(stderr,"testDLLwrite -v\n");
  fprintf(stderr,"testDLLwrite -compress\n");
  if (wait)
  {
    fprintf(stderr,"<press ENTER>\n");
    getc(stdin);
  }
  exit(1);
}

static void dll_error(pulsewaves_POINTER pulsewaves)
{
  if (pulsewaves != 0)
  {
    pulsewaves_CHAR* error;
    if (pulsewaves_get_error(pulsewaves, &error))
    {
      fprintf(stderr,"DLL ERROR: getting error messages\n");
    }
    fprintf(stderr,"DLL ERROR MESSAGE: %s\n", error);
  }
}

static void byebye(bool error=false, bool wait=false, pulsewaves_POINTER pulsewaves=0)
{
  if (error)
  {  
    dll_error(pulsewaves);
  }
  if (wait)
  {
    fprintf(stderr,"<press ENTER>\n");
    getc(stdin);
  }
  exit(error);
}

static double taketime()
{
  return (double)(clock())/CLOCKS_PER_SEC;
}

#define DESCRIPTOR_ONLY_OUTGOING                      1
#define DESCRIPTOR_ONE_LOW_VARYING                    2
#define DESCRIPTOR_TWO_LOW_VARYING                    3
#define DESCRIPTOR_THREE_LOW_VARYING                  4
#define DESCRIPTOR_ONE_HIGH_VARYING                   5
#define DESCRIPTOR_ONE_LOW_VARYING_ONE_HIGH_VARYING   6
#define DESCRIPTOR_TWO_LOW_VARYING_ONE_HIGH_VARYING   7
#define DESCRIPTOR_THREE_LOW_VARYING_ONE_HIGH_VARYING 8
#define DESCRIPTOR_X_LOW_VARYING_X_HIGH_VARYING       9

#define LOOKUP_TABLES_LOW  1
#define LOOKUP_TABLES_HIGH 2

static float lookup_table_low_amplitude[256] = { 
  PULSEWAVESDLL_EMPTY_TABLE_ENTRY, PULSEWAVESDLL_EMPTY_TABLE_ENTRY, PULSEWAVESDLL_EMPTY_TABLE_ENTRY,
  -8.4510f, -5.4407f, -3.6798f, -2.4304f, -1.4613f,
  -0.6695f, 0.0000f, 0.5799f, 1.0914f, 1.5490f, 1.9629f, 2.3408f, 2.6885f,
  3.0103f, 3.3099f, 3.5902f, 3.8535f, 4.1017f, 4.3366f, 4.5593f, 4.7712f,
  4.9732f, 5.1663f, 5.3511f, 5.5284f, 5.6988f, 5.8627f, 6.0206f, 6.1730f,
  6.3202f, 6.4626f, 6.6005f, 6.7342f, 6.8638f, 6.9897f, 7.1120f, 7.2310f,
  7.3469f, 7.4597f, 7.5696f, 7.6769f, 7.7815f, 7.8837f, 7.9835f, 8.0811f,
  8.1766f, 8.2700f, 8.3614f, 8.4510f, 8.5387f, 8.6247f, 8.7091f, 8.7918f,
  8.8730f, 8.9526f, 9.0309f, 9.1078f, 9.1833f, 9.2575f, 9.3305f, 9.4023f,
  9.4729f, 9.5424f, 9.6108f, 9.6782f, 9.7445f, 9.8098f, 9.8741f, 9.9375f,
  10.0000f, 10.0616f, 10.1223f, 10.1822f, 10.2413f, 10.2996f, 10.3572f, 10.4139f,
  10.4700f, 10.5253f, 10.5799f, 10.6339f, 10.6872f, 10.7398f, 10.7918f, 10.8432f,
  10.8940f, 10.9442f, 10.9938f, 11.0429f, 11.0914f, 11.1394f, 11.1869f, 11.2338f,
  11.2803f, 11.3263f, 11.3717f, 11.4167f, 11.4613f, 11.5054f, 11.5490f, 11.5922f,
  11.6350f, 11.6774f, 11.7194f, 11.8021f, 11.8429f, 11.8833f, 11.9233f, 12.0022f,
  12.0412f, 12.0798f, 12.1560f, 12.1936f, 12.2309f, 12.3045f, 12.3408f, 12.4126f,
  12.4481f, 12.5181f, 12.5871f, 12.6211f, 12.6885f, 12.7548f, 12.7875f, 12.8524f,
  12.9162f, 12.9792f, 13.0412f, 13.1024f, 13.1925f, 13.2809f, 13.3959f, 13.4803f,
  13.5902f, 13.6709f, 13.7762f, 13.8535f, 13.9295f, 13.9794f, 14.0532f, 14.1017f,
  14.1497f, 14.2207f, 14.2674f, 14.3136f, 14.3594f, 14.4046f, 14.4494f, 14.4937f,
  14.5375f, 14.5810f, 14.6240f, 14.6666f, 14.7087f, 14.7712f, 14.8124f, 14.8532f,
  14.9136f, 14.9732f, 15.0321f, 15.0901f, 15.1474f, 15.2039f, 15.2597f, 15.3330f,
  15.3872f, 15.4407f, 15.5110f, 15.5630f, 15.6314f, 15.6820f, 15.7320f, 15.7978f,
  15.8465f, 15.8947f, 15.9423f, 15.9895f, 16.0361f, 16.0669f, 16.1127f, 16.1429f,
  16.1880f, 16.2177f, 16.2619f, 16.2912f, 16.3347f, 16.3634f, 16.4062f, 16.4486f,
  16.4766f, 16.5183f, 16.5733f, 16.6141f, 16.6679f, 16.7078f, 16.7604f, 16.8253f,
  16.8766f, 16.9523f, 17.0391f, 17.1361f, 17.2428f, 17.3469f, 17.4485f, 17.5587f,
  17.6450f, 17.7400f, 17.8124f, 17.8837f, 17.9538f, 18.0131f, 18.0715f, 18.1291f,
  18.1860f, 18.2422f, 18.2884f, 18.3433f, 18.3975f, 18.4421f, 18.4951f, 18.5474f,
  18.5991f, 18.6587f, 18.7091f, 18.7671f, 18.8326f, 18.8890f, 18.9447f, 19.0076f,
  19.0695f, 19.1306f, 19.1908f, 19.2575f, 19.3233f, 19.3881f, 19.4519f, 19.5217f,
  19.5904f, 19.6648f, 19.7379f, 19.8098f, 19.8741f, 19.9438f, 20.0062f, 20.0738f,
  20.1524f, 20.2355f, 20.3342f, 20.4420f, 20.5690f, 20.7083f, 20.8330f, 20.9840f
};

static float lookup_table_low_range[256] = { 
  PULSEWAVESDLL_EMPTY_TABLE_ENTRY, PULSEWAVESDLL_EMPTY_TABLE_ENTRY, PULSEWAVESDLL_EMPTY_TABLE_ENTRY, -8.45098f, -2.43038f, 0.579919f, 3.30993f, 5.1663f, 6.73416f, 8.08114f, 9.1833f,
  10.1223f, 10.9938f, 11.7194f, 12.3769f, 13.0719f, 14.0532f, 14.6666f, 14.9336f, 15.1474f, 15.3148f, 15.4584f,
  15.5802f, 15.6988f, 15.7815f, 15.8627f, 15.9423f, 16.0051f, 16.0822f, 16.158f, 16.2472f, 16.3347f, 16.4486f, 
  16.5596f, 16.6945f, 16.8382f, 17.0021f, 17.16f, 17.3354f, 17.504f, 17.6769f, 17.8431f, 17.9934f, 18.1482f, 18.2884f,
  18.4154f, 18.5387f, 18.6502f, 18.7506f, 18.8407f, 18.9368f, 19.0154f, 19.1001f, 19.1758f, 19.2502f, 19.3233f,
  19.3952f, 19.4659f, 19.5355f, 19.604f, 19.6715f, 19.7445f, 19.8162f, 19.8932f, 19.9689f, 20.0494f, 20.1284f,
  20.2178f, 20.3054f, 20.397f, 20.4922f, 20.5962f, 20.7136f, 20.8381f, 20.9741f, 21.1155f, 21.2571f, 21.4033f, 
  21.5447f, 21.6858f, 21.8266f, 21.959f, 22.0875f, 22.2085f, 22.3227f, 22.4304f, 22.5285f, 22.6245f, 22.7151f, 
  22.8006f, 22.8876f, 22.9667f, 23.0474f, 23.1236f, 23.2015f, 23.275f, 23.3503f, 23.4242f, 23.4969f, 23.5712f, 
  23.6468f, 23.7212f, 23.7969f, 23.8764f, 23.9545f, 24.0361f, 24.1162f, 24.2019f, 24.2883f, 24.3752f, 24.4649f, 
  24.555f, 24.6453f, 24.738f, 24.8308f, 24.9236f, 25.0184f, 25.1112f, 25.2076f, 25.302f, 25.3979f, 25.4935f, 
  25.5905f, 25.687f, 25.7831f, 25.8803f, 25.977f, 26.0746f, 26.1715f, 26.2693f, 26.3663f, 26.4626f, 26.5596f, 
  26.6571f, 26.7539f, 26.8497f, 26.9461f, 27.0427f, 27.1385f, 27.2346f, 27.3297f, 27.425f, 27.5205f, 27.615f, 
  27.7096f, 27.8032f, 27.8978f, 27.9905f, 28.084f, 28.1766f, 28.2691f, 28.3641f, 28.4616f, 28.5612f, 28.662f, 
  28.7655f, 28.8697f, 28.9755f, 29.0826f, 29.1908f, 29.2993f, 29.4087f, 29.5182f, 29.6278f, 29.7379f, 29.8485f,
  29.9582f, 30.0683f, 30.1781f, 30.288f, 30.397f, 30.5055f, 30.6134f, 30.7209f, 30.8279f, 30.9342f, 31.04f, 
  31.1447f, 31.2488f, 31.3518f, 31.4542f, 31.556f, 31.6563f, 31.7564f, 31.855f, 31.9531f, 32.0501f, 32.1462f,
  32.2405f, 32.3325f, 32.4222f, 32.5108f, 32.598f, 32.6838f, 32.7692f, 32.8543f, 32.9387f, 33.0233f, 33.1081f,
  33.1931f, 33.2788f, 33.3652f, 33.4523f, 33.5403f, 33.6291f, 33.7194f, 33.8106f, 33.9033f, 33.9972f, 34.0926f,
  34.1894f, 34.2878f, 34.3877f, 34.489f, 34.5918f, 34.6961f, 34.8021f, 34.9094f, 35.0182f, 35.1284f, 35.2401f,
  35.3531f, 35.4674f, 35.583f, 35.6998f, 35.8177f, 35.9368f, 36.0569f, 36.1841f, 36.3237f, 36.4766f, 36.6432f, 
  36.8238f, 37.018f, 37.2258f, 37.4464f, 37.6791f, 37.9228f, 38.1768f, 38.4397f, 38.7106f, 38.9881f, 39.2712f, 
  39.5589f, 39.7128f, 39.7129f, 39.713f, 39.713f, 39.7131f, 39.7132f, 39.7132f, 39.7133f, 39.7134f, 39.7134f,
  39.7135f, 39.7136f
};

static float lookup_table_high_amplitude[256] = { 
  PULSEWAVESDLL_EMPTY_TABLE_ENTRY, PULSEWAVESDLL_EMPTY_TABLE_ENTRY, PULSEWAVESDLL_EMPTY_TABLE_ENTRY,
  -8.4510f, -2.4304f, 1.5490f, 4.1017f, 6.0206f,
  7.6769f, 8.9526f, 10.1223f, 11.0914f, 11.9233f, 12.6885f, 13.3388f, 13.9545f,
  14.7505f, 15.2965f, 15.6988f, 15.9423f, 16.0975f, 16.2177f, 16.3202f, 16.3920f,
  16.4766f, 16.5459f, 16.6276f, 16.7342f, 16.8638f, 17.0268f, 17.2428f, 17.4597f,
  17.6663f, 17.8329f, 17.9737f, 18.0908f, 18.2048f, 18.3160f, 18.4154f, 18.5213f,
  18.6162f, 18.7174f, 18.8244f, 18.9289f, 19.0386f, 19.1457f, 19.2502f, 19.3594f,
  19.4589f, 19.5562f, 19.6581f, 19.7510f, 19.8421f, 19.9312f, 20.0124f, 20.0982f,
  20.1763f, 20.2589f, 20.3400f, 20.4196f, 20.5088f, 20.5962f, 20.6872f, 20.7815f,
  20.8788f, 20.9790f, 21.0818f, 21.1869f, 21.2941f, 21.4033f, 21.5098f, 21.6180f,
  21.7277f, 21.8347f, 21.9392f, 22.0451f, 22.1522f, 22.2531f, 22.3553f, 22.4551f,
  22.5527f, 22.6482f, 22.7416f, 22.8330f, 22.9226f, 23.0103f, 23.0993f, 23.1836f,
  23.2692f, 23.3531f, 23.4355f, 23.5218f, 23.6038f, 23.6869f, 23.7710f, 23.8561f,
  23.9395f, 24.0263f, 24.1114f, 24.1996f, 24.2860f, 24.3752f, 24.4649f, 24.5550f,
  24.6474f, 24.7380f, 24.8308f, 24.9216f, 25.0145f, 25.1054f, 25.1964f, 25.2892f,
  25.3818f, 25.4725f, 25.5647f, 25.6568f, 25.7502f, 25.8417f, 25.9344f, 26.0268f,
  26.1187f, 26.2103f, 26.3028f, 26.3949f, 26.4878f, 26.5801f, 26.6719f, 26.7643f,
  26.8561f, 26.9486f, 27.0415f, 27.1325f, 27.2252f, 27.3170f, 27.4093f, 27.5007f,
  27.5924f, 27.6843f, 27.7753f, 27.8665f, 27.9578f, 28.0492f, 28.1396f, 28.2301f,
  28.3214f, 28.4118f, 28.5021f, 28.5948f, 28.6898f, 28.7877f, 28.8874f, 28.9896f,
  29.0933f, 29.1982f, 29.3051f, 29.4123f, 29.5210f, 29.6298f, 29.7392f, 29.8491f,
  29.9595f, 30.0702f, 30.1805f, 30.2904f, 30.4004f, 30.5104f, 30.6194f, 30.7283f,
  30.8366f, 30.9442f, 31.0517f, 31.1580f, 31.2636f, 31.3686f, 31.4728f, 31.5759f,
  31.6782f, 31.7795f, 31.8800f, 31.9799f, 32.0787f, 32.1763f, 32.2730f, 32.3686f,
  32.4629f, 32.5548f, 32.6448f, 32.7333f, 32.8204f, 32.9067f, 32.9920f, 33.0768f,
  33.1612f, 33.2458f, 33.3302f, 33.4146f, 33.4997f, 33.5853f, 33.6714f, 33.7585f,
  33.8464f, 33.9352f, 34.0253f, 34.1164f, 34.2087f, 34.3024f, 34.3972f, 34.4932f,
  34.5909f, 34.6898f, 34.7902f, 34.8919f, 34.9949f, 35.0995f, 35.2052f, 35.3124f,
  35.4208f, 35.5305f, 35.6416f, 35.7537f, 35.8670f, 35.9813f, 36.0969f, 36.2132f,
  36.3314f, 36.4597f, 36.6011f, 36.7557f, 36.9229f, 37.1024f, 37.2936f, 37.4957f,
  37.7079f, 37.9293f, 38.1590f, 38.3960f, 38.6395f, 38.8884f, 39.1418f, 39.3990f,
  39.6591f, 39.7126f, 39.7127f, 39.7128f, 39.7128f, 39.7129f, 39.7130f, 39.7130f,
  39.7131f, 39.7132f, 39.7132f, 39.7133f, 39.7134f, 39.7134f, 39.7135f, 39.7136
};

static float lookup_table_high_range[256] = { 
  PULSEWAVESDLL_EMPTY_TABLE_ENTRY, PULSEWAVESDLL_EMPTY_TABLE_ENTRY, PULSEWAVESDLL_EMPTY_TABLE_ENTRY, -8.45098f, -2.43038f, 0.579919f, 3.30993f, 5.1663f, 6.73416f, 8.08114f, 9.1833f,
  10.1223f, 10.9938f, 11.7194f, 12.3769f, 13.0719f, 14.0532f, 14.6666f, 14.9336f, 15.1474f, 15.3148f, 15.4584f,
  15.5802f, 15.6988f, 15.7815f, 15.8627f, 15.9423f, 16.0051f, 16.0822f, 16.158f, 16.2472f, 16.3347f, 16.4486f, 
  16.5596f, 16.6945f, 16.8382f, 17.0021f, 17.16f, 17.3354f, 17.504f, 17.6769f, 17.8431f, 17.9934f, 18.1482f, 18.2884f,
  18.4154f, 18.5387f, 18.6502f, 18.7506f, 18.8407f, 18.9368f, 19.0154f, 19.1001f, 19.1758f, 19.2502f, 19.3233f,
  19.3952f, 19.4659f, 19.5355f, 19.604f, 19.6715f, 19.7445f, 19.8162f, 19.8932f, 19.9689f, 20.0494f, 20.1284f,
  20.2178f, 20.3054f, 20.397f, 20.4922f, 20.5962f, 20.7136f, 20.8381f, 20.9741f, 21.1155f, 21.2571f, 21.4033f, 
  21.5447f, 21.6858f, 21.8266f, 21.959f, 22.0875f, 22.2085f, 22.3227f, 22.4304f, 22.5285f, 22.6245f, 22.7151f, 
  22.8006f, 22.8876f, 22.9667f, 23.0474f, 23.1236f, 23.2015f, 23.275f, 23.3503f, 23.4242f, 23.4969f, 23.5712f, 
  23.6468f, 23.7212f, 23.7969f, 23.8764f, 23.9545f, 24.0361f, 24.1162f, 24.2019f, 24.2883f, 24.3752f, 24.4649f, 
  24.555f, 24.6453f, 24.738f, 24.8308f, 24.9236f, 25.0184f, 25.1112f, 25.2076f, 25.302f, 25.3979f, 25.4935f, 
  25.5905f, 25.687f, 25.7831f, 25.8803f, 25.977f, 26.0746f, 26.1715f, 26.2693f, 26.3663f, 26.4626f, 26.5596f, 
  26.6571f, 26.7539f, 26.8497f, 26.9461f, 27.0427f, 27.1385f, 27.2346f, 27.3297f, 27.425f, 27.5205f, 27.615f, 
  27.7096f, 27.8032f, 27.8978f, 27.9905f, 28.084f, 28.1766f, 28.2691f, 28.3641f, 28.4616f, 28.5612f, 28.662f, 
  28.7655f, 28.8697f, 28.9755f, 29.0826f, 29.1908f, 29.2993f, 29.4087f, 29.5182f, 29.6278f, 29.7379f, 29.8485f,
  29.9582f, 30.0683f, 30.1781f, 30.288f, 30.397f, 30.5055f, 30.6134f, 30.7209f, 30.8279f, 30.9342f, 31.04f, 
  31.1447f, 31.2488f, 31.3518f, 31.4542f, 31.556f, 31.6563f, 31.7564f, 31.855f, 31.9531f, 32.0501f, 32.1462f,
  32.2405f, 32.3325f, 32.4222f, 32.5108f, 32.598f, 32.6838f, 32.7692f, 32.8543f, 32.9387f, 33.0233f, 33.1081f,
  33.1931f, 33.2788f, 33.3652f, 33.4523f, 33.5403f, 33.6291f, 33.7194f, 33.8106f, 33.9033f, 33.9972f, 34.0926f,
  34.1894f, 34.2878f, 34.3877f, 34.489f, 34.5918f, 34.6961f, 34.8021f, 34.9094f, 35.0182f, 35.1284f, 35.2401f,
  35.3531f, 35.4674f, 35.583f, 35.6998f, 35.8177f, 35.9368f, 36.0569f, 36.1841f, 36.3237f, 36.4766f, 36.6432f, 
  36.8238f, 37.018f, 37.2258f, 37.4464f, 37.6791f, 37.9228f, 38.1768f, 38.4397f, 38.7106f, 38.9881f, 39.2712f, 
  39.5589f, 39.7128f, 39.7129f, 39.713f, 39.713f, 39.7131f, 39.7132f, 39.7132f, 39.7133f, 39.7134f, 39.7134f,
  39.7135f, 39.7136f
};

int main(int argc, char *argv[])
{
  int i;
  bool verbose = false;
  bool compress = false;
  char file_name[9] = "test.pls";

  // load pulsewaves DLL

  if (pulsewaves_load_dll())
  {
    fprintf(stderr,"DLL ERROR: loading pulsewaves DLL\n");
    byebye(true, argc==1);
  }

  // get version of pulsewaves DLL

  pulsewaves_U8 version_major;
  pulsewaves_U8 version_minor;
  pulsewaves_U16 version_revision;
  pulsewaves_U32 version_build;

  if (pulsewaves_get_version(&version_major, &version_minor, &version_revision, &version_build))
  {
    fprintf(stderr,"DLL ERROR: getting pulsewaves DLL version number\n");
    byebye(true, argc==1);
  }

  for (i = 1; i < argc; i++)
  {
    if (strcmp(argv[i],"-h") == 0 || strcmp(argv[i],"-help") == 0)
    {
      fprintf(stderr, "testDLLwrite of PULSEtools (by martin.isenburg@rapidlasso.com) version: %d.%d r%d (build %d)\n", version_major, version_minor, version_revision, version_build);
      usage();
    }
    else if (strcmp(argv[i],"-version") == 0)
    {
      fprintf(stderr, "testDLLwrite of PULSEtools (by martin.isenburg@rapidlasso.com) version: %d.%d r%d (build %d)\n", version_major, version_minor, version_revision, version_build);
      byebye();
    }
    else if (strcmp(argv[i],"-v") == 0 || strcmp(argv[i],"-verbose") == 0)
    {
      verbose = true;
    }
    else if (strcmp(argv[i],"-compress") == 0)
    {
      compress = true;
    }
    else
    {
      fprintf(stderr, "ERROR: cannot understand argument '%s'\n", argv[i]);
      usage();
    }
  }

  if (verbose)
  {
    fprintf(stderr,"pulsewaves DLL version: %d.%d r%d (build %d)\n", version_major, version_minor, version_revision, version_build);
    if (compress)
      fprintf(stderr,"writing to test.plz & test.wvz\n");
    else
      fprintf(stderr,"writing to test.pls & test.wvs\n");
  }

  // create object in pulsewaves DLL

  pulsewaves_POINTER pulsewaves;
  if (pulsewaves_create(&pulsewaves))
  {
    fprintf(stderr,"DLL ERROR: creating pulsewaves object\n");
    byebye(true, argc==1);
  }

  // populate header

  pulsewaves_header header;

  // get the default header

  if (pulsewaves_header_get(pulsewaves, &header))
  {
    fprintf(stderr,"DLL ERROR: getting the default pulsewaves header\n");
    byebye(true, argc==1, pulsewaves);
  }

  header.file_source_ID = 4711;
  sprintf(header.system_identifier, "testDLLwrite - PulseWaves DLL prototype tester");
  header.file_creation_day = 13;
  header.file_creation_year = 2013;
  header.number_of_pulses = 15;

  // *** t_offset test ***
  header.t_offset = 0; 

  // set the header

  if (pulsewaves_header_set(pulsewaves, &header))
  {
    fprintf(stderr,"DLL ERROR: setting pulsewaves header\n");
    byebye(true, argc==1, pulsewaves);
  }

  // populate the scanner
  
  pulsewaves_scanner scanner;

  // get default scanner settings

  if (pulsewaves_header_get_scanner(pulsewaves, &scanner, 0))
  {
    fprintf(stderr,"DLL ERROR: getting default scanner settings\n");
    byebye(true, argc==1, pulsewaves);
  }
  strncpy(scanner.instrument, "RIEGL Q560", PULSEWAVESDLL_DESCRIPTION_SIZE);
  strncpy(scanner.serial, "RMS-2011-00232-13", PULSEWAVESDLL_DESCRIPTION_SIZE);
  scanner.wave_length = 1064.0f;                  // [nanometer]
  scanner.outgoing_pulse_width = 4.0f;            // [nanoseconds]
  scanner.scan_pattern = 2;                       // 0 = undefined, 1 = oscillating, 2 = line, 3 = conic
  scanner.number_of_mirror_facets = 4;
  scanner.scan_frequency = 160.0f;                // [hertz]
  scanner.scan_angle_min = -30.0f;                // [degree]
  scanner.scan_angle_max = +30.0f;                // [degree]
  scanner.pulse_frequency = 240.0f;               // [kilohertz]
  scanner.beam_diameter_at_exit_aperture = 10.0f; // [millimeters]
  scanner.beam_divergence = 0.3f;                 // [milliradians]
  scanner.minimal_range = 100.0f;                 // [meters]
  scanner.maximal_range = 4200.0f;                // [meters]
  strncpy(scanner.description, "scanner description generated by testDLLwrite.exe", PULSEWAVESDLL_DESCRIPTION_SIZE);

  // add scanner with index 1 to the header 

  if (pulsewaves_header_add_scanner(pulsewaves, &scanner, 1))
  {
    fprintf(stderr,"DLL ERROR: adding scanner to header\n");
    byebye(true, argc==1, pulsewaves);
  }

  // create nine pulsedescriptors (pulsecomposition + pulsesamplings)

  pulsewaves_pulsecomposition_struct composition;
  pulsewaves_pulsesampling_struct samplings[3];

  // create 1st pulsedescriptor for pulses without returning waveform

  composition.optical_center_to_anchor_point = 0;            // the duration between optical center and anchor point is zero
  composition.number_of_extra_waves_bytes = 0; 
  composition.number_of_samplings = 1;                       // one outgoing only, none returning
  composition.sample_units = 1.0f;                           // [nanoseconds]
  composition.scanner_index = 1;                             // the pulse was recorded by the scanner with index 1
  memset(composition.description, 0, PULSEWAVESDLL_DESCRIPTION_SIZE);
  strncpy(composition.description, "only outgoing, no returning", PULSEWAVESDLL_DESCRIPTION_SIZE);

  samplings[0].type = PULSEWAVESDLL_OUTGOING;
  samplings[0].channel = 0;
  samplings[0].bits_for_duration_from_anchor = 0;            // the anchor point is the optical center. this is when the outgoing waveform starts.
  samplings[0].scale_for_duration_from_anchor = 1.0f;        // not-applicable, but needs proper initialization
  samplings[0].offset_for_duration_from_anchor = 0.0f;       // not-applicable, but needs proper initialization
  samplings[0].bits_for_number_of_segments = 0;              // the number of segments is fixed (i.e. there is just one)
  samplings[0].bits_for_number_of_samples = 0;               // the number of samples is fixed (i.e. it is always 24)
  samplings[0].number_of_segments = 1;                       // the number of segments per sampling is always 1
  samplings[0].number_of_samples = 24;                       // the number of samples per segment is always 24
  samplings[0].bits_per_sample = 8;                          // the number of bits per sample is always 8
  samplings[0].lookup_table_index = PULSEWAVESDLL_UNDEFINED; // there is no lookup table for translating sample values to physical measurements
  samplings[0].sample_units = 1.0f;                          // [nanoseconds]
  memset(samplings[0].description, 0, PULSEWAVESDLL_DESCRIPTION_SIZE);
  strncpy(samplings[0].description, "outgoing, 24 samples, 8 bits", PULSEWAVESDLL_DESCRIPTION_SIZE);

  // add 1st pulsedescriptor to the header

  if (pulsewaves_header_add_pulsedescriptor(pulsewaves, &composition, samplings, DESCRIPTOR_ONLY_OUTGOING))
  {
    fprintf(stderr,"DLL ERROR: adding pulsedescriptor %d to header\n", DESCRIPTOR_ONLY_OUTGOING);
    byebye(true, argc==1, pulsewaves);
  }

  // create 2nd pulsedescriptor for pulses with one returning waveform composed of one low segment with varying sample number

  composition.optical_center_to_anchor_point = 0;            // the duration between optical center and anchor point is zero
  composition.number_of_extra_waves_bytes = 0; 
  composition.number_of_samplings = 2;                       // one outgoing, one returning (with one low segment)
  composition.sample_units = 1.0f;                           // [nanoseconds]
  composition.scanner_index = 1;                             // the pulse was recorded by the scanner with index 1
  memset(composition.description, 0, PULSEWAVESDLL_DESCRIPTION_SIZE);
  strncpy(composition.description, "outgoing + returning, 1 low segment, varying", PULSEWAVESDLL_DESCRIPTION_SIZE);

  samplings[1].type = PULSEWAVESDLL_RETURNING;
  samplings[1].channel = 0;
  samplings[1].bits_for_duration_from_anchor = 16;           // the start of each waveform segment is specified with 16 bits (in sampling units) 
  samplings[1].scale_for_duration_from_anchor = 0.1f;        // the 16 bit duration is quantized and must first be multiplied with 0.1f ...
  samplings[1].offset_for_duration_from_anchor = 8192.0f;    // ... and then offset by +8192.0f to get the actual duration value
  samplings[1].bits_for_number_of_segments = 0;              // the number of segments is fixed (i.e. there is exactly one)
  samplings[1].bits_for_number_of_samples = 8;               // the number of samples per segment is specified per segment with 8 bits
  samplings[1].number_of_segments = 1;                       // the number of segments per sampling is always 1
  samplings[1].number_of_samples = 0;                        // the number of samples per segment varies
  samplings[1].bits_per_sample = 8;                          // the number of bits per sample is always 8
  samplings[1].lookup_table_index = LOOKUP_TABLES_LOW;       // the index to the optional lookup table translating sample values to physical measurements
  samplings[1].sample_units = 1.0f;                          // [nanoseconds]
  memset(samplings[1].description, 0, PULSEWAVESDLL_DESCRIPTION_SIZE);
  strncpy(samplings[1].description, "returning, 1 low segment, varying, 8 bits", PULSEWAVESDLL_DESCRIPTION_SIZE);

  // add 2nd pulsedescriptor to the header

  if (pulsewaves_header_add_pulsedescriptor(pulsewaves, &composition, samplings, DESCRIPTOR_ONE_LOW_VARYING))
  {
    fprintf(stderr,"DLL ERROR: adding pulsedescriptor %d to header\n", DESCRIPTOR_ONE_LOW_VARYING);
    byebye(true, argc==1, pulsewaves);
  }

  // create 3rd pulsedescriptor for pulses with one returning waveform composed of two low segments with varying sample number

  composition.optical_center_to_anchor_point = 0;            // the duration between optical center and anchor point is zero
  composition.number_of_extra_waves_bytes = 0; 
  composition.number_of_samplings = 2;                       // one outgoing, one returning (with two low segments)
  composition.sample_units = 1.0f;                           // [nanoseconds]
  composition.scanner_index = 1;                             // the pulse was recorded by the scanner with index 1
  memset(composition.description, 0, PULSEWAVESDLL_DESCRIPTION_SIZE);
  strncpy(composition.description, "outgoing + returning, 2 low segments, varying", PULSEWAVESDLL_DESCRIPTION_SIZE);

  samplings[1].type = PULSEWAVESDLL_RETURNING;
  samplings[1].channel = 0;
  samplings[1].bits_for_duration_from_anchor = 16;           // the start of each waveform segment is specified with 16 bits (in sampling units) 
  samplings[1].scale_for_duration_from_anchor = 0.1f;        // the 16 bit duration is quantized and must first be multiplied with 0.1f ...
  samplings[1].offset_for_duration_from_anchor = 8192.0f;    // ... and then offset by +8192.0f to get the actual duration value
  samplings[1].bits_for_number_of_segments = 0;              // the number of segments is fixed (i.e. there are exactly two)
  samplings[1].bits_for_number_of_samples = 8;               // the number of samples per segment is specified per segment with 8 bits
  samplings[1].number_of_segments = 2;                       // the number of segments per sampling is always 2
  samplings[1].number_of_samples = 0;                        // the number of samples per segment varies
  samplings[1].bits_per_sample = 8;                          // the number of bits per sample is always 8
  samplings[1].lookup_table_index = LOOKUP_TABLES_LOW;       // the index to the (optional) lookup table translating sample values to physical measurements
  samplings[1].sample_units = 1.0f;                          // [nanoseconds]
  memset(samplings[1].description, 0, PULSEWAVESDLL_DESCRIPTION_SIZE);
  strncpy(samplings[1].description, "returning, 2 low segments, varying, 8 bits", PULSEWAVESDLL_DESCRIPTION_SIZE);

  // add 3rd pulsedescriptor to the header

  if (pulsewaves_header_add_pulsedescriptor(pulsewaves, &composition, samplings, DESCRIPTOR_TWO_LOW_VARYING))
  {
    fprintf(stderr,"DLL ERROR: adding pulsedescriptor %d to header\n", DESCRIPTOR_TWO_LOW_VARYING);
    byebye(true, argc==1, pulsewaves);
  }

  // create 4th pulsedescriptor for pulses with one returning waveform composed of three low segments with varying sample number

  composition.optical_center_to_anchor_point = 0;            // the duration between optical center and anchor point is zero
  composition.number_of_extra_waves_bytes = 0; 
  composition.number_of_samplings = 2;                       // one outgoing, one returning (with three low segments)
  composition.sample_units = 1.0f;                           // [nanoseconds]
  composition.scanner_index = 1;                             // the pulse was recorded by the scanner with index 1
  memset(composition.description, 0, PULSEWAVESDLL_DESCRIPTION_SIZE);
  strncpy(composition.description, "outgoing + returning, 3 low segments, varying", PULSEWAVESDLL_DESCRIPTION_SIZE);

  samplings[1].type = PULSEWAVESDLL_RETURNING;
  samplings[1].channel = 0;
  samplings[1].bits_for_duration_from_anchor = 16;           // the start of each waveform segment is specified with 16 bits (in sampling units) 
  samplings[1].scale_for_duration_from_anchor = 0.1f;        // the 16 bit duration is quantized and must first be multiplied with 0.1f ...
  samplings[1].offset_for_duration_from_anchor = 8192.0f;    // ... and then offset by +8192.0f to get the actual duration value
  samplings[1].bits_for_number_of_segments = 0;              // the number of segments is fixed (i.e. there are exactly three)
  samplings[1].bits_for_number_of_samples = 8;               // the number of samples per segment is specified per segment with 8 bits
  samplings[1].number_of_segments = 3;                       // the number of segments per sampling is always 3
  samplings[1].number_of_samples = 0;                        // the number of samples per segment varies
  samplings[1].bits_per_sample = 8;                          // the number of bits per sample is always 8
  samplings[1].lookup_table_index = LOOKUP_TABLES_LOW;       // the index to the optional lookup table translating sample values to physical measurements
  samplings[1].sample_units = 1.0f;                          // [nanoseconds]
  memset(samplings[1].description, 0, PULSEWAVESDLL_DESCRIPTION_SIZE);
  strncpy(samplings[1].description, "returning, 3 low segments, varying, 8 bits", PULSEWAVESDLL_DESCRIPTION_SIZE);

  // add 4th pulsedescriptor to the header

  if (pulsewaves_header_add_pulsedescriptor(pulsewaves, &composition, samplings, DESCRIPTOR_THREE_LOW_VARYING))
  {
    fprintf(stderr,"DLL ERROR: adding pulsedescriptor %d to header\n", DESCRIPTOR_THREE_LOW_VARYING);
    byebye(true, argc==1, pulsewaves);
  }

  // create 5th pulsedescriptor for pulses with one returning waveform composed of one high segment with varying sample number
  
  composition.optical_center_to_anchor_point = 0;            // the duration between optical center and anchor point is zero
  composition.number_of_extra_waves_bytes = 0; 
  composition.number_of_samplings = 2;                       // one outgoing, one returning (with one high segment)
  composition.sample_units = 1.0f;                           // [nanoseconds]
  composition.scanner_index = 1;                             // the pulse was recorded by the scanner with index 1
  memset(composition.description, 0, PULSEWAVESDLL_DESCRIPTION_SIZE);
  strncpy(composition.description, "outgoing + returning, 1 high segment, varying", PULSEWAVESDLL_DESCRIPTION_SIZE);

  samplings[1].type = PULSEWAVESDLL_RETURNING;
  samplings[1].channel = 1;
  samplings[1].bits_for_duration_from_anchor = 32;           // the start of each waveform segment is specified with 32 bits (in sampling units) 
  samplings[1].scale_for_duration_from_anchor = 0.02f;       // the 32 bit duration is quantized and must first be multiplied with 0.02f ...
  samplings[1].offset_for_duration_from_anchor = 0.0f;       // ... and then offset by 0.0f to get the actual duration value
  samplings[1].bits_for_number_of_segments = 0;              // the number of segments is fixed (i.e. there is exactly one)
  samplings[1].bits_for_number_of_samples = 8;               // the number of samples per segment is specified per segment with 8 bits
  samplings[1].number_of_segments = 1;                       // the number of segments per sampling is always 1
  samplings[1].number_of_samples = 0;                        // the number of samples per segment varies
  samplings[1].bits_per_sample = 8;                          // the number of bits per sample is always 8
  samplings[1].lookup_table_index = LOOKUP_TABLES_HIGH;      // the index to the optional lookup table translating sample values to physical measurements
  samplings[1].sample_units = 1.0f;                          // [nanoseconds]
  memset(samplings[1].description, 0, PULSEWAVESDLL_DESCRIPTION_SIZE);
  strncpy(samplings[1].description, "returning, 1 high segment, varying, 8 bits", PULSEWAVESDLL_DESCRIPTION_SIZE);

  // add 5th pulsedescriptor to the header

  if (pulsewaves_header_add_pulsedescriptor(pulsewaves, &composition, samplings, DESCRIPTOR_ONE_HIGH_VARYING))
  {
    fprintf(stderr,"DLL ERROR: adding pulsedescriptor %d to header\n", DESCRIPTOR_ONE_HIGH_VARYING);
    byebye(true, argc==1, pulsewaves);
  }
  
  // create 6th pulsedescriptor for pulses with one returning waveform composed of one low segment and one high segment with varying sample number

  composition.optical_center_to_anchor_point = 0;            // the duration between optical center and anchor point is zero
  composition.number_of_extra_waves_bytes = 0; 
  composition.number_of_samplings = 3;                       // one outgoing, two returning (one with one low segment, one with one high segment)
  composition.sample_units = 1.0f;                           // [nanoseconds]
  composition.scanner_index = 1;                             // the pulse was recorded by the scanner with index 1
  memset(composition.description, 0, PULSEWAVESDLL_DESCRIPTION_SIZE);
  strncpy(composition.description, "outgoing + returning, 1 low segment, 1 high segment, varying", PULSEWAVESDLL_DESCRIPTION_SIZE);

  samplings[1].type = PULSEWAVESDLL_RETURNING;
  samplings[1].channel = 0;
  samplings[1].bits_for_duration_from_anchor = 16;           // the start of each waveform segment is specified with 16 bits (in sampling units) 
  samplings[1].scale_for_duration_from_anchor = 0.1f;        // the 16 bit duration is quantized and must first be multiplied with 0.1f ...
  samplings[1].offset_for_duration_from_anchor = 8192.0f;    // ... and then offset by +8192.0f to get the actual duration value
  samplings[1].bits_for_number_of_segments = 0;              // the number of segments is fixed (i.e. there is just one)
  samplings[1].bits_for_number_of_samples = 8;               // the number of samples per segment is specified per segment with 8 bits
  samplings[1].number_of_segments = 1;                       // the number of segments per sampling is always 1
  samplings[1].number_of_samples = 0;                        // the number of samples per segment varies
  samplings[1].bits_per_sample = 8;                          // the number of bits per sample is always 8
  samplings[1].lookup_table_index = LOOKUP_TABLES_LOW;       // the index to the optional lookup table translating sample values to physical measurements
  samplings[1].sample_units = 1.0f;                          // [nanoseconds]
  memset(samplings[1].description, 0, PULSEWAVESDLL_DESCRIPTION_SIZE);
  strncpy(samplings[1].description, "returning, 1 low segment, varying, 8 bits", PULSEWAVESDLL_DESCRIPTION_SIZE);

  samplings[2].type = PULSEWAVESDLL_RETURNING;
  samplings[2].channel = 1;
  samplings[2].bits_for_duration_from_anchor = 32;           // the start of each waveform segment is specified with 32 bits (in sampling units) 
  samplings[2].scale_for_duration_from_anchor = 0.02f;       // the 32 bit duration is quantized and must first be multiplied with 0.02f ...
  samplings[2].offset_for_duration_from_anchor = 0.0f;       // ... and then offset by 0.0f to get the actual duration value
  samplings[2].bits_for_number_of_segments = 0;              // the number of segments is fixed (i.e. there is exactly one)
  samplings[2].bits_for_number_of_samples = 8;               // the number of samples per segment is specified per segment with 8 bits
  samplings[2].number_of_segments = 1;                       // the number of segments per sampling is always 1
  samplings[2].number_of_samples = 0;                        // the number of samples per segment varies
  samplings[2].bits_per_sample = 8;                          // the number of bits per sample is always 8
  samplings[2].lookup_table_index = LOOKUP_TABLES_HIGH;      // the index to the optional lookup table translating sample values to physical measurements
  samplings[2].sample_units = 1.0f;                          // [nanoseconds]
  memset(samplings[2].description, 0, PULSEWAVESDLL_DESCRIPTION_SIZE);
  strncpy(samplings[2].description, "returning, 1 high segment, varying, 8 bits", PULSEWAVESDLL_DESCRIPTION_SIZE);

  // add 6th pulsedescriptor to the header

  if (pulsewaves_header_add_pulsedescriptor(pulsewaves, &composition, samplings, DESCRIPTOR_ONE_LOW_VARYING_ONE_HIGH_VARYING))
  {
    fprintf(stderr,"DLL ERROR: adding pulsedescriptor %d to header\n", DESCRIPTOR_ONE_LOW_VARYING_ONE_HIGH_VARYING);
    byebye(true, argc==1, pulsewaves);
  }

  // create 7th pulsedescriptor for pulses with one returning waveform composed of two low segments and one high segment with varying sample number

  composition.optical_center_to_anchor_point = 0;            // the duration between optical center and anchor point is zero
  composition.number_of_extra_waves_bytes = 0; 
  composition.number_of_samplings = 3;                       // one outgoing, two returning (one with two low segments, one with one high segment)
  composition.sample_units = 1.0f;                           // [nanoseconds]
  composition.scanner_index = 1;                             // the pulse was recorded by the scanner with index 1
  memset(composition.description, 0, PULSEWAVESDLL_DESCRIPTION_SIZE);
  strncpy(composition.description, "outgoing + returning, 2 low segments, 1 high segment, varying", PULSEWAVESDLL_DESCRIPTION_SIZE);

  samplings[1].type = PULSEWAVESDLL_RETURNING;
  samplings[1].channel = 0;
  samplings[1].bits_for_duration_from_anchor = 16;           // the start of each waveform segment is specified with 16 bits (in sampling units) 
  samplings[1].scale_for_duration_from_anchor = 0.1f;        // the 16 bit duration is quantized and must first be multiplied with 0.1f ...
  samplings[1].offset_for_duration_from_anchor = 8192.0f;    // ... and then offset by +8192.0f to get the actual duration value
  samplings[1].bits_for_number_of_segments = 0;              // the number of segments is fixed (i.e. there are exactly two)
  samplings[1].bits_for_number_of_samples = 8;               // the number of samples per segment is specified per segment with 8 bits
  samplings[1].number_of_segments = 2;                       // the number of segments per sampling is always 2
  samplings[1].number_of_samples = 0;                        // the number of samples per segment varies
  samplings[1].bits_per_sample = 8;                          // the number of bits per sample is always 8
  samplings[1].lookup_table_index = LOOKUP_TABLES_LOW;       // the index to the optional lookup table translating sample values to physical measurements
  samplings[1].sample_units = 1.0f;                          // [nanoseconds]
  memset(samplings[1].description, 0, PULSEWAVESDLL_DESCRIPTION_SIZE);
  strncpy(samplings[1].description, "returning, 2 low segments, varying, 8 bits", PULSEWAVESDLL_DESCRIPTION_SIZE);  
  
  samplings[2].type = PULSEWAVESDLL_RETURNING;
  samplings[2].channel = 1;
  samplings[2].bits_for_duration_from_anchor = 32;           // the start of each waveform segment is specified with 32 bits (in sampling units) 
  samplings[2].scale_for_duration_from_anchor = 0.02f;       // the 32 bit duration is quantized and must first be multiplied with 0.02f ...
  samplings[2].offset_for_duration_from_anchor = 0.0f;       // ... and then offset by 0.0f to get the actual duration value
  samplings[2].bits_for_number_of_segments = 0;              // the number of segments is fixed (i.e. there is exactly one)
  samplings[2].bits_for_number_of_samples = 8;               // the number of samples per segment is specified per segment with 8 bits
  samplings[2].number_of_segments = 1;                       // the number of segments per sampling is always 1
  samplings[2].number_of_samples = 0;                        // the number of samples per segment varies
  samplings[2].bits_per_sample = 8;                          // the number of bits per sample is always 8
  samplings[2].lookup_table_index = LOOKUP_TABLES_HIGH;      // the index to the optional lookup table translating sample values to physical measurements
  samplings[2].sample_units = 1.0f;                          // [nanoseconds]
  memset(samplings[2].description, 0, PULSEWAVESDLL_DESCRIPTION_SIZE);
  strncpy(samplings[2].description, "returning, 1 high segment, varying, 8 bits", PULSEWAVESDLL_DESCRIPTION_SIZE);

  // add 7th pulsedescriptor to the header

  if (pulsewaves_header_add_pulsedescriptor(pulsewaves, &composition, samplings, DESCRIPTOR_TWO_LOW_VARYING_ONE_HIGH_VARYING))
  {
    fprintf(stderr,"DLL ERROR: adding pulsedescriptor %d to header\n", DESCRIPTOR_TWO_LOW_VARYING_ONE_HIGH_VARYING);
    byebye(true, argc==1, pulsewaves);
  }
  
  // create 8th pulsedescriptor for pulses with one returning waveform composed of three low segments and one high segment with varying sample number

  composition.optical_center_to_anchor_point = 0;            // the duration between optical center and anchor point is zero
  composition.number_of_extra_waves_bytes = 0; 
  composition.number_of_samplings = 3;                       // one outgoing, two returning (one with three low segments, one with one high segment)
  composition.sample_units = 1.0f;                           // [nanoseconds]
  composition.scanner_index = 1;                             // the pulse was recorded by the scanner with index 1
  memset(composition.description, 0, PULSEWAVESDLL_DESCRIPTION_SIZE);
  strncpy(composition.description, "outgoing + returning, 3 low segments, 1 high segment, varying", PULSEWAVESDLL_DESCRIPTION_SIZE);

  samplings[1].type = PULSEWAVESDLL_RETURNING;
  samplings[1].channel = 0;
  samplings[1].bits_for_duration_from_anchor = 16;           // the start of each waveform segment is specified with 16 bits (in sampling units) 
  samplings[1].scale_for_duration_from_anchor = 0.1f;        // the 16 bit duration is quantized and must first be multiplied with 0.1f ...
  samplings[1].offset_for_duration_from_anchor = 8192.0f;    // ... and then offset by +8192.0f to get the actual duration value
  samplings[1].bits_for_number_of_segments = 0;              // the number of segments is fixed (i.e. there are exactly three)
  samplings[1].bits_for_number_of_samples = 8;               // the number of samples per segment is specified per segment with 8 bits
  samplings[1].number_of_segments = 3;                       // the number of segments per sampling is always 3
  samplings[1].number_of_samples = 0;                        // the number of samples per segment varies
  samplings[1].bits_per_sample = 8;                          // the number of bits per sample is always 8
  samplings[1].lookup_table_index = LOOKUP_TABLES_LOW;       // the index to the optional lookup table translating sample values to physical measurements
  samplings[1].sample_units = 1.0f;                          // [nanoseconds]
  memset(samplings[1].description, 0, PULSEWAVESDLL_DESCRIPTION_SIZE);
  strncpy(samplings[1].description, "returning, 3 low segments, varying, 8 bits", PULSEWAVESDLL_DESCRIPTION_SIZE);

  samplings[2].type = PULSEWAVESDLL_RETURNING;
  samplings[2].channel = 1;
  samplings[2].bits_for_duration_from_anchor = 32;           // the start of each waveform segment is specified with 32 bits (in sampling units) 
  samplings[2].scale_for_duration_from_anchor = 0.02f;       // the 32 bit duration is quantized and must first be multiplied with 0.02f ...
  samplings[2].offset_for_duration_from_anchor = 0.0f;       // ... and then offset by 0.0f to get the actual duration value
  samplings[2].bits_for_number_of_segments = 0;              // the number of segments is fixed (i.e. there is exactly one)
  samplings[2].bits_for_number_of_samples = 8;               // the number of samples per segment is specified per segment with 8 bits
  samplings[2].number_of_segments = 1;                       // the number of segments per sampling is always 1
  samplings[2].number_of_samples = 0;                        // the number of samples per segment varies
  samplings[2].bits_per_sample = 8;                          // the number of bits per sample is always 8
  samplings[2].lookup_table_index = LOOKUP_TABLES_HIGH;      // the index to the optional lookup table translating sample values to physical measurements
  samplings[2].sample_units = 1.0f;                          // [nanoseconds]
  memset(samplings[2].description, 0, PULSEWAVESDLL_DESCRIPTION_SIZE);
  strncpy(samplings[2].description, "returning, 1 high segment, varying, 8 bits", PULSEWAVESDLL_DESCRIPTION_SIZE);

  // add 8th pulsedescriptor to the header

  if (pulsewaves_header_add_pulsedescriptor(pulsewaves, &composition, samplings, DESCRIPTOR_THREE_LOW_VARYING_ONE_HIGH_VARYING))
  {
    fprintf(stderr,"DLL ERROR: adding pulsedescriptor %d to header\n", DESCRIPTOR_THREE_LOW_VARYING_ONE_HIGH_VARYING);
    byebye(true, argc==1, pulsewaves);
  }

  // create 9th pulsedescriptor for pulses with one returning waveform composed of x low segments and x high segments with varying sample number

  composition.optical_center_to_anchor_point = 0;            // the duration between optical center and anchor point is zero
  composition.number_of_extra_waves_bytes = 0; 
  composition.number_of_samplings = 3;                       // one outgoing, two returning (one with x low segments, one with x high segments)
  composition.sample_units = 1.0f;                           // [nanoseconds]
  composition.scanner_index = 1;                             // the pulse was recorded by the scanner with index 1
  memset(composition.description, 0, PULSEWAVESDLL_DESCRIPTION_SIZE);
  strncpy(composition.description, "outgoing + returning, x low segments, x high segments, varying", PULSEWAVESDLL_DESCRIPTION_SIZE);

  samplings[1].type = PULSEWAVESDLL_RETURNING;
  samplings[1].channel = 0;
  samplings[1].bits_for_duration_from_anchor = 16;           // the start of each waveform segment is specified with 16 bits (in sampling units) 
  samplings[1].scale_for_duration_from_anchor = 0.1f;        // the 16 bit duration is quantized and must first be multiplied with 0.1f ...
  samplings[1].offset_for_duration_from_anchor = 8192.0f;    // ... and then offset by +8192.0f to get the actual duration value
  samplings[1].bits_for_number_of_segments = 8;              // the number of segments in sampling is specified with 8 bits
  samplings[1].bits_for_number_of_samples = 8;               // the number of samples per segment is specified per segment with 8 bits
  samplings[1].number_of_segments = 0;                       // the number of segments in sampling varies
  samplings[1].number_of_samples = 0;                        // the number of samples per segment varies
  samplings[1].bits_per_sample = 8;                          // the number of bits per sample is always 8
  samplings[1].lookup_table_index = LOOKUP_TABLES_LOW;       // the index to the optional lookup table translating sample values to physical measurements
  samplings[1].sample_units = 1.0f;                          // [nanoseconds]
  memset(samplings[1].description, 0, PULSEWAVESDLL_DESCRIPTION_SIZE);
  strncpy(samplings[1].description, "returning, x low segments, varying, 8 bits", PULSEWAVESDLL_DESCRIPTION_SIZE);

  samplings[2].type = PULSEWAVESDLL_RETURNING;
  samplings[2].channel = 1;
  samplings[2].bits_for_duration_from_anchor = 32;           // the start of each waveform segment is specified with 32 bits (in sampling units) 
  samplings[2].scale_for_duration_from_anchor = 0.02f;       // the 32 bit duration is quantized and must first be multiplied with 0.02f ...
  samplings[2].offset_for_duration_from_anchor = 0.0f;       // ... and then offset by 0.0f to get the actual duration value
  samplings[2].bits_for_number_of_segments = 8;              // the number of segments in sampling is specified with 8 bits
  samplings[2].bits_for_number_of_samples = 8;               // the number of samples per segment is specified per segment with 8 bits
  samplings[2].number_of_segments = 0;                       // the number of segments in sampling varies
  samplings[2].number_of_samples = 0;                        // the number of samples per segment varies
  samplings[2].bits_per_sample = 8;                          // the number of bits per sample is always 8
  samplings[2].lookup_table_index = LOOKUP_TABLES_HIGH;      // the index to the optional lookup table translating sample values to physical measurements
  samplings[2].sample_units = 1.0f;                          // [nanoseconds]
  memset(samplings[2].description, 0, PULSEWAVESDLL_DESCRIPTION_SIZE);
  strncpy(samplings[2].description, "returning, x high segments, varying, 8 bits", PULSEWAVESDLL_DESCRIPTION_SIZE);

  // add 9th pulsedescriptor to the header

  if (pulsewaves_header_add_pulsedescriptor(pulsewaves, &composition, samplings, DESCRIPTOR_X_LOW_VARYING_X_HIGH_VARYING))
  {
    fprintf(stderr,"DLL ERROR: adding pulsedescriptor %d to header\n", DESCRIPTOR_X_LOW_VARYING_X_HIGH_VARYING);
    byebye(true, argc==1, pulsewaves);
  }

  // add the lookup tables for the low channel
  
  pulsewaves_lookup_table lookup_tables_low[2];

  lookup_tables_low[0].number_entries = 256;
  lookup_tables_low[0].unit_of_measurement = PULSEWAVESDLL_TABLE_INTENSITY_CORRECTION; // 0 = undefined
  lookup_tables_low[0].data_type = 8;                 // 8 = float
  lookup_tables_low[0].options = 0;                   // must be 0
  strncpy(lookup_tables_low[0].description, "amplitude calibration table for low channel", PULSEWAVESDLL_DESCRIPTION_SIZE);
  lookup_tables_low[0].entries = (pulsewaves_U8*)lookup_table_low_amplitude;

  lookup_tables_low[1].number_entries = 256;
  lookup_tables_low[1].unit_of_measurement = PULSEWAVESDLL_TABLE_RANGE_CORRECTION; // 0 = undefined
  lookup_tables_low[1].data_type = 8;                 // 8 = float
  lookup_tables_low[1].options = 0;                   // must be 0
  strncpy(lookup_tables_low[1].description, "range calibration table for low channel", PULSEWAVESDLL_DESCRIPTION_SIZE);
  lookup_tables_low[1].entries = (pulsewaves_U8*)lookup_table_low_range;

  // add lookup table for low channel to the header using index LOOKUP_TABLES_LOW

  if (pulsewaves_header_add_lookup_tables(pulsewaves, 2, lookup_tables_low, LOOKUP_TABLES_LOW))
  {
    fprintf(stderr,"DLL ERROR: adding lookup_tables_low to header with table_index %d\n", LOOKUP_TABLES_LOW);
    byebye(true, argc==1, pulsewaves);
  }
  
  // add the lookup tables for the high channel

  pulsewaves_lookup_table lookup_tables_high[2];

  lookup_tables_high[0].number_entries = 256;
  lookup_tables_high[0].unit_of_measurement = PULSEWAVESDLL_TABLE_INTENSITY_CORRECTION; // 0 = undefined, 1 = intensity correction, 2 = range correction
  lookup_tables_high[0].data_type = 8;                 // 8 = float
  lookup_tables_high[0].options = 0;                   // must be 0
  strncpy(lookup_tables_high[0].description, "amplitude calibration table for high channel", PULSEWAVESDLL_DESCRIPTION_SIZE);
  lookup_tables_high[0].entries = (pulsewaves_U8*)lookup_table_high_amplitude;

  lookup_tables_high[1].number_entries = 256;
  lookup_tables_high[1].unit_of_measurement = PULSEWAVESDLL_TABLE_RANGE_CORRECTION; // 0 = undefined, 1 = intensity correction, 2 = range correction
  lookup_tables_high[1].data_type = 8;                 // 8 = float
  lookup_tables_high[1].options = 0;                   // must be 0
  strncpy(lookup_tables_high[1].description, "range calibration table for high channel", PULSEWAVESDLL_DESCRIPTION_SIZE);
  lookup_tables_high[1].entries = (pulsewaves_U8*)lookup_table_high_range;

  // add lookup table for high channel to the header using index LOOKUP_TABLES_HIGH

  if (pulsewaves_header_add_lookup_tables(pulsewaves, 2, lookup_tables_high, LOOKUP_TABLES_HIGH))
  {
    fprintf(stderr,"DLL ERROR: adding lookup_tables_high to header with table_index %d\n", LOOKUP_TABLES_HIGH);
    byebye(true, argc==1, pulsewaves);
  }

  // add geo-referencing VLR to the header via geokeys

  if (0) // geographic coordinates
  {
    pulsewaves_pulsekeyentry key_entries[4];

    // geographic coordinates
    key_entries[0].key_id = 1024; // GTModelTypeGeoKey
    key_entries[0].tiff_tag_location = 0;
    key_entries[0].count = 1;
    key_entries[0].value_offset = 2; // ModelTypeGeographic

    // ellipsoid used with latitude/longitude coordinates
    key_entries[1].key_id = 2048; // GeographicTypeGeoKey
    key_entries[1].tiff_tag_location = 0;
    key_entries[1].count = 1;
    key_entries[1].value_offset = 4326; // WGS84

    // vertical units
    key_entries[2].key_id = 4099; // VerticalUnitsGeoKey
    key_entries[2].tiff_tag_location = 0;
    key_entries[2].count = 1;
    key_entries[2].value_offset = 9001; // meters

    // vertical datum
    key_entries[3].key_id = 4096; // VerticalCSTypeGeoKey
    key_entries[3].tiff_tag_location = 0;
    key_entries[3].count = 1;
    key_entries[3].value_offset = 5030; // WGS84

    if (pulsewaves_header_set_geokey_entries(pulsewaves, 4, key_entries))
    {
      fprintf(stderr,"DLL ERROR: adding 4 geokey_entries to header\n");
      byebye(true, argc==1, pulsewaves);
    }
  }
  else if (0) // user-defined LLC projection
  {
    pulsewaves_pulsekeyentry key_entries[13];
    pulsewaves_F64 double_params[6];

    // projected coordinates
    key_entries[0].key_id = 1024; // GTModelTypeGeoKey
    key_entries[0].tiff_tag_location = 0;
    key_entries[0].count = 1;
    key_entries[0].value_offset = 1; // ModelTypeProjected

    // user-defined custom LCC projection 
    key_entries[1].key_id = 3072; // ProjectedCSTypeGeoKey
    key_entries[1].tiff_tag_location = 0;
    key_entries[1].count = 1;
    key_entries[1].value_offset = 32767; // user-defined

    // which projection do we use
    key_entries[2].key_id = 3075; // ProjCoordTransGeoKey
    key_entries[2].tiff_tag_location = 0;
    key_entries[2].count = 1;
    key_entries[2].value_offset = 8; // CT_LambertConfConic_2SP 

    // which units do we use
    key_entries[3].key_id = 3076; // ProjCoordTransGeoKey
    key_entries[3].tiff_tag_location = 0;
    key_entries[3].count = 1;
    key_entries[3].value_offset = 9001; // meters

    // here come the 6 double parameters
      
    key_entries[4].key_id = 3078; // ProjStdParallel1GeoKey
    key_entries[4].tiff_tag_location = 34736;
    key_entries[4].count = 1;
    key_entries[4].value_offset = 0;
    double_params[0] = 51.16666723;

    key_entries[5].key_id = 3079; // ProjStdParallel2GeoKey
    key_entries[5].tiff_tag_location = 34736;
    key_entries[5].count = 1;
    key_entries[5].value_offset = 1;
    double_params[1] = 49.8333339;

    key_entries[6].key_id = 3088; // ProjCenterLongGeoKey
    key_entries[6].tiff_tag_location = 34736;
    key_entries[6].count = 1;
    key_entries[6].value_offset = 2;
    double_params[2] = 4.367486667;

    key_entries[7].key_id = 3081; // ProjNatOriginLatGeoKey
    key_entries[7].tiff_tag_location = 34736;
    key_entries[7].count = 1;
    key_entries[7].value_offset = 3;
    double_params[3] = 90;

    key_entries[8].key_id = 3082; // ProjFalseEastingGeoKey
    key_entries[8].tiff_tag_location = 34736;
    key_entries[8].count = 1;
    key_entries[8].value_offset = 4;
    double_params[4] = 150000.013;

    key_entries[9].key_id = 3083; // ProjFalseNorthingGeoKey
    key_entries[9].tiff_tag_location = 34736;
    key_entries[9].count = 1;
    key_entries[9].value_offset = 5;
    double_params[5] = 5400088.438; 

    // ellipsoid
    key_entries[10].key_id = 2056; // GeogEllipsoidGeoKey
    key_entries[10].tiff_tag_location = 0;
    key_entries[10].count = 1;
    key_entries[10].value_offset = 7022; // Ellipse_International1924

    // vertical units
    key_entries[11].key_id = 4099; // VerticalUnitsGeoKey
    key_entries[11].tiff_tag_location = 0;
    key_entries[11].count = 1;
    key_entries[11].value_offset = 9001; // meters

    // vertical datum
    key_entries[12].key_id = 4096; // VerticalCSTypeGeoKey
    key_entries[12].tiff_tag_location = 0;
    key_entries[12].count = 1;
    key_entries[12].value_offset = 5030; // WGS84

    if (pulsewaves_header_set_geokey_entries(pulsewaves, 13, key_entries))
    {
      fprintf(stderr,"DLL ERROR: adding 13 geokey_entries to header\n");
      byebye(true, argc==1, pulsewaves);
    }

    if (pulsewaves_header_set_geodouble_params(pulsewaves, 6, double_params))
    {
      fprintf(stderr,"DLL ERROR: adding 6 geodouble_params to header\n");
      byebye(true, argc==1, pulsewaves);
    }
  }
  else // add pre-defined projection (here: WGS84_UTM_zone_13N)
  {
    pulsewaves_pulsekeyentry key_entries[5];

    // projected coordinates
    key_entries[0].key_id = 1024; // GTModelTypeGeoKey
    key_entries[0].tiff_tag_location = 0;
    key_entries[0].count = 1;
    key_entries[0].value_offset = 1; // ModelTypeProjected

    // projection
    key_entries[1].key_id = 3072; // ProjectedCSTypeGeoKey
    key_entries[1].tiff_tag_location = 0;
    key_entries[1].count = 1;
    key_entries[1].value_offset = 32613; // PCS_WGS84_UTM_zone_13N

    // horizontal units
    key_entries[2].key_id = 3076; // ProjLinearUnitsGeoKey
    key_entries[2].tiff_tag_location = 0;
    key_entries[2].count = 1;
    key_entries[2].value_offset = 9001; // meters

    // vertical units
    key_entries[3].key_id = 4099; // VerticalUnitsGeoKey
    key_entries[3].tiff_tag_location = 0;
    key_entries[3].count = 1;
    key_entries[3].value_offset = 9001; // meters

    // vertical datum
    key_entries[4].key_id = 4096; // VerticalCSTypeGeoKey
    key_entries[4].tiff_tag_location = 0;
    key_entries[4].count = 1;
    key_entries[4].value_offset = 5030; // WGS84

    if (pulsewaves_header_set_geokey_entries(pulsewaves, 5, key_entries))
    {
      fprintf(stderr,"DLL ERROR: adding 5 geokey_entries to header\n");
      byebye(true, argc==1, pulsewaves);
    }
  }

  // add some other random VLR to the header

  pulsewaves_pulsevlr vlr;
  strncpy(vlr.user_id, "random VLR", PULSEWAVESDLL_USER_ID_SIZE);
  vlr.record_id = 4711;
  vlr.record_length_after_header = 8;
  pulsewaves_CHAR data[8] = "hallo!!";

  if (pulsewaves_header_add_vlr(pulsewaves, &vlr, (pulsewaves_U8*)data))
  {
    fprintf(stderr,"DLL ERROR: adding vlr with user_id '%s' and record_id %d to header\n", vlr.user_id, vlr.record_id);
    byebye(true, argc==1, pulsewaves);
  }

  // for compressed output change file ending from PLS to PLZ

  if (compress)
  {
    file_name[7] = 'z';
  }

  // open the writer

  if (pulsewaves_writer_open(pulsewaves, file_name, compress))
  {
    fprintf(stderr,"DLL ERROR: opening pulsewaves writer\n");
    byebye(true, argc==1, pulsewaves);
  }

  pulsewaves_pulse_struct pulse;

  // setup 1st pulse

  pulse.T = 129863735377; // to get Standard GPS time in seconds, scale by 1e-6 and add 1e9 seconds

  pulse.anchor[0] = 235006.189; 
  pulse.anchor[1] = 800051.276;
  pulse.anchor[2] = 1261.177; 
  
  pulse.target[0] = 235006.189 + 1000.0 * 0.0422858574893;
  pulse.target[1] = 800051.276 - 1000.0 * 0.0139114190461;
  pulse.target[2] = 1261.177 - 1000.0 * 0.143093129736;

  pulse.first_returning_sample = 8213;
  pulse.last_returning_sample = 8251;
  pulse.descriptor_index = DESCRIPTOR_ONE_LOW_VARYING; // outgoing + returning (one low segment)
  pulse.edge_of_scan_line = 0;
  pulse.scan_direction = 0;
  pulse.mirror_facet = 2;
  pulse.intensity = 0;
  pulse.classification = 0;

  // write 1st pulse

  if (pulsewaves_writer_write_pulse(pulsewaves, &pulse))
  {
    fprintf(stderr,"DLL ERROR: writing 1st pulse\n");
    byebye(true, argc==1, pulsewaves);
  }

  // setup 1st waves

  pulsewaves_wavessampling wavessampling1[2];

  // setup 1st wavessampling[0] (outgoing, 1 segment, 24 samples, 8 bits)

  pulsewaves_I32 outgoing1_num_samples[1] = { 24 };
  pulsewaves_F32 outgoing1_durations[1] = { 0.0f };
  pulsewaves_U8 outgoing1_samples_segment0[24] = { 2,2,2,2,3,9,19,34,57,91,143,167,127,82,55,23,9,6,3,2,2,2,2,2 } ;
  pulsewaves_U8* outgoing1_samples[1];
  outgoing1_samples[0] = outgoing1_samples_segment0;

  wavessampling1[0].num_segments = 1;
  wavessampling1[0].num_samples = outgoing1_num_samples;
  wavessampling1[0].durations = outgoing1_durations;
  wavessampling1[0].samples = outgoing1_samples;

  // setup 1st wavessampling1[1] (returning, 1 segment, 39 samples, 8 bits)

  pulsewaves_I32 returning1_num_samples[1] = { 39 };
  pulsewaves_F32 returning1_durations[1] = { 8212.7534f };
  pulsewaves_U8 returning1_samples_segment0[39] = { 2,2,2,2,2,2,2,2,2,2,2,2,5,9,22,39,57,78,101,127,138,151,120,101,88,56,43,33,21,14,9,6,4,3,2,2,2,2,2 } ;
  pulsewaves_U8* returning1_samples[1];
  returning1_samples[0] = returning1_samples_segment0;

  wavessampling1[1].num_segments = 1;
  wavessampling1[1].num_samples = returning1_num_samples;
  wavessampling1[1].durations = returning1_durations;
  wavessampling1[1].samples = returning1_samples;

  // write 1st waves

  if (pulsewaves_writer_write_waves(pulsewaves, wavessampling1, 2))
  {
    fprintf(stderr,"DLL ERROR: writing 1st waves\n");
    byebye(true, argc==1, pulsewaves);
  }

  // setup 2nd pulse

  pulse.T = 129863735407; // to get Standard GPS time in seconds, scale by 1e-6 and add 1e9 seconds

  pulse.anchor[0] = 235006.247; 
  pulse.anchor[1] = 800051.461;
  pulse.anchor[2] = 1261.178; 
  
  pulse.target[0] = 235006.247 + 1000.0 * 0.0422858574893;
  pulse.target[1] = 800051.461 - 1000.0 * 0.0139114190461;
  pulse.target[2] = 1261.178 - 1000.0 * 0.143093129736;

  pulse.first_returning_sample = 8219;
  pulse.last_returning_sample = 8270;
  pulse.descriptor_index = DESCRIPTOR_TWO_LOW_VARYING; // outgoing + returning (two low segment)
  pulse.edge_of_scan_line = 0;
  pulse.scan_direction = 0;
  pulse.mirror_facet = 2;
  pulse.intensity = 0;
  pulse.classification = 0;

  // write 2nd pulse

  if (pulsewaves_writer_write_pulse(pulsewaves, &pulse))
  {
    fprintf(stderr,"DLL ERROR: writing 2nd pulse\n");
    byebye(true, argc==1, pulsewaves);
  }

  // setup 2nd waves

  pulsewaves_wavessampling wavessampling2[2];

  // setup 2nd wavessampling[0] (outgoing, 1 segment, 24 samples, 8 bits)

  pulsewaves_I32 outgoing2_num_samples[1] = { 24 };
  pulsewaves_F32 outgoing2_durations[1] = { 0.0f };
  pulsewaves_U8 outgoing2_samples_segment0[24] = { 2,3,9,21,34,54,94,141,165,124,80,57,24,8,5,3,2,2,2,2,2,2,2,2 } ;
  pulsewaves_U8* outgoing2_samples[1];
  outgoing2_samples[0] = outgoing2_samples_segment0;

  wavessampling2[0].num_segments = 1;
  wavessampling2[0].num_samples = outgoing2_num_samples;
  wavessampling2[0].durations = outgoing2_durations;
  wavessampling2[0].samples = outgoing2_samples;

  // setup 2nd wavessampling2[1] (returning, 2 segments, 29 and 11 samples, 8 bits)

  pulsewaves_I32 returning2_num_samples[2] = { 29, 11 };
  pulsewaves_F32 returning2_durations[2] = { 8218.75f, 8259.125f };
  pulsewaves_U8 returning2_samples_segment0[29] = { 2,2,2,5,9,22,39,57,78,101,88,128,131,128,71,85,52,48,37,29,14,9,7,6,5,4,3,2,2 } ;
  pulsewaves_U8 returning2_samples_segment1[11] = { 2,5,9,47,78,34,9,7,6,5,2 } ;
  pulsewaves_U8* returning2_samples[2];
  returning2_samples[0] = returning2_samples_segment0;
  returning2_samples[1] = returning2_samples_segment1;

  wavessampling2[1].num_segments = 2;
  wavessampling2[1].num_samples = returning2_num_samples;
  wavessampling2[1].durations = returning2_durations;
  wavessampling2[1].samples = returning2_samples;

  // write 2nd waves

  if (pulsewaves_writer_write_waves(pulsewaves, wavessampling2, 2))
  {
    fprintf(stderr,"DLL ERROR: writing 2nd waves\n");
    byebye(true, argc==1, pulsewaves);
  }

  // setup 3rd pulse

  pulse.T = 129863735435; // to get Standard GPS time in seconds, scale by 1e-6 and add 1e9 seconds

  pulse.anchor[0] = 235006.341; 
  pulse.anchor[1] = 800051.681;
  pulse.anchor[2] = 1261.554; 
  
  pulse.target[0] = 235006.341 + 1000.0 * 0.0422858574893;
  pulse.target[1] = 800051.681 - 1000.0 * 0.0139114190461;
  pulse.target[2] = 1261.554 - 1000.0 * 0.143093129736;

  pulse.first_returning_sample = 8227;
  pulse.last_returning_sample = 8266;
  pulse.descriptor_index = DESCRIPTOR_ONE_LOW_VARYING_ONE_HIGH_VARYING; // 1 outgoing + 2 returning (one low segment + 1 high segment)
  pulse.edge_of_scan_line = 0;
  pulse.scan_direction = 0;
  pulse.mirror_facet = 2;
  pulse.intensity = 0;
  pulse.classification = 0;

  // write 3rd pulse

  if (pulsewaves_writer_write_pulse(pulsewaves, &pulse))
  {
    fprintf(stderr,"DLL ERROR: writing 3rd pulse\n");
    byebye(true, argc==1, pulsewaves);
  }

  // setup 3rd waves

  pulsewaves_wavessampling wavessampling3[3];

  // setup 3rd wavessampling3[0] (outgoing, 1 segment, 24 samples, 8 bits)

  pulsewaves_I32 outgoing3_num_samples[1] = { 24 };
  pulsewaves_F32 outgoing3_durations[1] = { 0.0f };
  pulsewaves_U8 outgoing3_samples_segment0[24] = { 2,3,9,21,34,54,94,141,165,124,80,57,24,8,5,3,2,2,2,2,2,2,2,2 } ;
  pulsewaves_U8* outgoing3_samples[1];
  outgoing3_samples[0] = outgoing3_samples_segment0;

  wavessampling3[0].num_segments = 1;
  wavessampling3[0].num_samples = outgoing3_num_samples;
  wavessampling3[0].durations = outgoing3_durations;
  wavessampling3[0].samples = outgoing3_samples;

  // setup 3rd wavessampling3[1] (returning low, 1 segment, 39 samples, 8 bits)

  pulsewaves_I32 returning3_low_num_samples[1] = { 39 };
  pulsewaves_F32 returning3_low_durations[1] = { 8226.625f };
  pulsewaves_U8 returning3_low_samples_segment0[39] = { 2,3,7,39,89,117,178,201,255,255,255,255,197,152,84,173,76,49,4,9,7,6,5,4,3,2,2,2,2,2,2,2,2,2,2,2,2,2,2 } ;
  pulsewaves_U8* returning3_low_samples[1];
  returning3_low_samples[0] = returning3_low_samples_segment0;

  wavessampling3[1].num_segments = 1;
  wavessampling3[1].num_samples = returning3_low_num_samples;
  wavessampling3[1].durations = returning3_low_durations;
  wavessampling3[1].samples = returning3_low_samples;

  // setup 3rd wavessampling3[2] (returning high, 1 segment, 22 samples, 8 bits)

  pulsewaves_I32 returning3_high_num_samples[1] = { 22 };
  pulsewaves_F32 returning3_high_durations[1] = { 8229.75f };
  pulsewaves_U8 returning3_high_samples_segment0[22] = { 7,19,27,58,81,115,134,102,88,47,22,14,11,7,4,3,2,2,2,2,2,2 } ;
  pulsewaves_U8* returning3_high_samples[1];
  returning3_high_samples[0] = returning3_high_samples_segment0;

  wavessampling3[2].num_segments = 1;
  wavessampling3[2].num_samples = returning3_high_num_samples;
  wavessampling3[2].durations = returning3_high_durations;
  wavessampling3[2].samples = returning3_high_samples;

  // write 3rd waves

  if (pulsewaves_writer_write_waves(pulsewaves, wavessampling3, 3))
  {
    fprintf(stderr,"DLL ERROR: writing 3rd waves\n");
    byebye(true, argc==1, pulsewaves);
  }
  
  // setup 4th pulse

  pulse.T = 129863735435; // to get Standard GPS time in seconds, scale by 1e-6 and add 1e9 seconds

  pulse.anchor[0] = 235006.441; 
  pulse.anchor[1] = 800051.721;
  pulse.anchor[2] = 1261.384; 
  
  pulse.target[0] = 235006.441 + 1000.0 * 0.0422858574893;
  pulse.target[1] = 800051.721 - 1000.0 * 0.0139114190461;
  pulse.target[2] = 1261.384 - 1000.0 * 0.143093129736;

  pulse.first_returning_sample = 0;
  pulse.last_returning_sample = 0;
  pulse.descriptor_index = DESCRIPTOR_ONLY_OUTGOING; // 1 outgoing only - nothing returns
  pulse.edge_of_scan_line = 0;
  pulse.scan_direction = 0;
  pulse.mirror_facet = 2;
  pulse.intensity = 0;
  pulse.classification = 0;

  // write 4th pulse

  if (pulsewaves_writer_write_pulse(pulsewaves, &pulse))
  {
    fprintf(stderr,"DLL ERROR: writing 4th pulse\n");
    byebye(true, argc==1, pulsewaves);
  }

  // setup 4th waves

  pulsewaves_wavessampling wavessampling4[1];

  // setup 4th wavessampling4[0] (outgoing, 1 segment, 24 samples, 8 bits)

  pulsewaves_I32 outgoing4_num_samples[1] = { 24 };
  pulsewaves_F32 outgoing4_durations[1] = { 0.0f };
  pulsewaves_U8 outgoing4_samples_segment0[24] = { 2,2,2,2,3,9,17,33,56,82,135,161,129,87,52,26,9,6,4,2,2,2,2,2 } ;
  pulsewaves_U8* outgoing4_samples[1];
  outgoing4_samples[0] = outgoing4_samples_segment0;

  wavessampling4[0].num_segments = 1;
  wavessampling4[0].num_samples = outgoing4_num_samples;
  wavessampling4[0].durations = outgoing4_durations;
  wavessampling4[0].samples = outgoing4_samples;

  // write 4th waves

  if (pulsewaves_writer_write_waves(pulsewaves, wavessampling4, 1))
  {
    fprintf(stderr,"DLL ERROR: writing 4th waves\n");
    byebye(true, argc==1, pulsewaves);
  }

  // setup 5th pulse

  pulse.T = 129863735435; // to get Standard GPS time in seconds, scale by 1e-6 and add 1e9 seconds

  pulse.anchor[0] = 235006.617; 
  pulse.anchor[1] = 800051.809;
  pulse.anchor[2] = 1261.231; 
  
  pulse.target[0] = 235006.617 + 1000.0 * 0.0422858574893;
  pulse.target[1] = 800051.809 - 1000.0 * 0.0139114190461;
  pulse.target[2] = 1261.231 - 1000.0 * 0.143093129736;

  pulse.first_returning_sample = 8224;
  pulse.last_returning_sample = 8257;
  pulse.descriptor_index = DESCRIPTOR_X_LOW_VARYING_X_HIGH_VARYING; // 1 outgoing + 2 returning (x low segments + x high segments)
  pulse.edge_of_scan_line = 0;
  pulse.scan_direction = 0;
  pulse.mirror_facet = 2;
  pulse.intensity = 0;
  pulse.classification = 0;

  // write 5th pulse

  if (pulsewaves_writer_write_pulse(pulsewaves, &pulse))
  {
    fprintf(stderr,"DLL ERROR: writing 5th pulse\n");
    byebye(true, argc==1, pulsewaves);
  }

  // setup 5th waves

  pulsewaves_wavessampling wavessampling5[3];

  // setup 5th wavessampling5[0] (outgoing, 1 segment, 24 samples, 8 bits)

  pulsewaves_I32 outgoing5_num_samples[1] = { 24 };
  pulsewaves_F32 outgoing5_durations[1] = { 0.0f };
  pulsewaves_U8 outgoing5_samples_segment0[24] = { 2,2,2,3,5,28,33,48,99,131,155,114,90,67,17,7,6,5,4,3,2,2,2,2 } ;
  pulsewaves_U8* outgoing5_samples[1];
  outgoing5_samples[0] = outgoing5_samples_segment0;

  wavessampling5[0].num_segments = 1;
  wavessampling5[0].num_samples = outgoing5_num_samples;
  wavessampling5[0].durations = outgoing5_durations;
  wavessampling5[0].samples = outgoing5_samples;

  // setup 5th wavessampling5[1] (returning low, 1 segment, 39 samples, 8 bits)

  pulsewaves_I32 returning5_low_num_samples[1] = { 33 };
  pulsewaves_F32 returning5_low_durations[1] = { 8224.25f };
  pulsewaves_U8 returning5_low_samples_segment0[33] = { 2,3,7,39,89,117,178,201,255,255,255,255,197,152,84,173,76,49,4,9,7,6,5,4,3,2,2,2,2,2,2,2,2 } ;
  pulsewaves_U8* returning5_low_samples[1];
  returning5_low_samples[0] = returning5_low_samples_segment0;

  wavessampling5[1].num_segments = 1;
  wavessampling5[1].num_samples = returning5_low_num_samples;
  wavessampling5[1].durations = returning5_low_durations;
  wavessampling5[1].samples = returning5_low_samples;

  // setup 5th wavessampling5[2] (returning high, 1 segment, 19 samples, 8 bits)

  pulsewaves_I32 returning5_high_num_samples[1] = { 19 };
  pulsewaves_F32 returning5_high_durations[1] = { 8226.5f };
  pulsewaves_U8 returning5_high_samples_segment0[19] = { 2,2,5,15,23,48,71,101,130,92,81,40,32,24,16,9,6,4,2 } ;
  pulsewaves_U8* returning5_high_samples[1];
  returning5_high_samples[0] = returning5_high_samples_segment0;

  wavessampling5[2].num_segments = 1;
  wavessampling5[2].num_samples = returning5_high_num_samples;
  wavessampling5[2].durations = returning5_high_durations;
  wavessampling5[2].samples = returning5_high_samples;

  // write 5th waves

  if (pulsewaves_writer_write_waves(pulsewaves, wavessampling5, 3))
  {
    fprintf(stderr,"DLL ERROR: writing 5th waves\n");
    byebye(true, argc==1, pulsewaves);
  }

  // write line of 10 more pulses that are shifted versions of the last pulse and slowly get shorter

  pulse.first_returning_sample = 8219;
  pulse.last_returning_sample = 8270;

  for (int j = 1; j <= 10; j++)
  {
    // modify the 5th pulse and write with 2nd waves

    pulse.T += 30;
    pulse.anchor[0] += 0.1f; 
    pulse.anchor[1] += 0.1f;
    pulse.target[0] += 0.1f; 
    pulse.target[1] += 0.1f;
    pulse.descriptor_index = DESCRIPTOR_TWO_LOW_VARYING; // outgoing + returning (two low segment)
    pulse.last_returning_sample -= 1;
    returning2_num_samples[0] -= 1;

    // write j + 5th pulse

    if (pulsewaves_writer_write_pulse(pulsewaves, &pulse))
    {
      fprintf(stderr,"DLL ERROR: writing %d + 5th pulse\n", j);
      byebye(true, argc==1, pulsewaves);
    }

    // write j + 5th waves

    if (pulsewaves_writer_write_waves(pulsewaves, wavessampling2, 2))
    {
      fprintf(stderr,"DLL ERROR: writing %d + 2nd waves\n", j);
      byebye(true, argc==1, pulsewaves);
    }
  }

  // close the writer

  if (pulsewaves_writer_close(pulsewaves))
  {
    fprintf(stderr,"DLL ERROR: closing pulsewaves writer\n");
    byebye(true, argc==1, pulsewaves);
  }

  // destroy object in pulsewaves DLL

  if (pulsewaves_destroy(pulsewaves))
  {
    fprintf(stderr,"DLL ERROR: destroying pulsewaves object\n");
    byebye(true, argc==1);
  }

  return 0;
}
