/*
===============================================================================

  FILE:  pulsewaves_dll.h
  
  CONTENTS:
  
    A simple DLL interface to the PulseWaves library
  
  PROGRAMMERS:
  
    martin.isenburg@gmail.com  -  http://rapidlasso.com
  
  COPYRIGHT:
  
    (c) 2007-2012, martin isenburg, rapidlasso - fast tools to catch reality

    This is free software; you can redistribute and/or modify it under the
    terms of the GNU Lesser General Licence as published by the Free Software
    Foundation. See the COPYING file for more information.

    This software is distributed WITHOUT ANY WARRANTY and without even the
    implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  
  CHANGE HISTORY:
  
    5 September 2012 -- at RIEGL headquarters to get PulseWaves into RiProcess
  
===============================================================================
*/

#ifndef PULSEWAVES_DLL_H
#define PULSEWAVES_DLL_H

#ifdef _WIN32
#   ifdef PULSEWAVES_DYN_LINK
#       ifdef PULSEWAVES_SOURCE
#           define PULSEWAVES_API __declspec(dllexport)
#       else
#           define PULSEWAVES_API __declspec(dllimport)
#       endif
#   else
#       define PULSEWAVES_API
#   endif
#else
#   define PULSEWAVES_API
#endif

#ifdef __cplusplus
extern "C"
{
#endif

typedef int                pulsewaves_BOOL;
typedef unsigned char      pulsewaves_U8;
typedef unsigned short     pulsewaves_U16;
typedef unsigned int       pulsewaves_U32;
typedef char               pulsewaves_I8;
typedef short              pulsewaves_I16;
typedef int                pulsewaves_I32;
typedef __int64            pulsewaves_I64;
typedef char               pulsewaves_CHAR;
typedef float              pulsewaves_F32;
typedef double             pulsewaves_F64;
typedef void*              pulsewaves_POINTER;

#define PULSEWAVES_OUTGOING   1
#define PULSEWAVES_RETURNING  2

typedef struct pulsewaves_header
{
  pulsewaves_U32 version;
  pulsewaves_U32 scan_ID;
  pulsewaves_U32 project_ID_GUID_data_1;
  pulsewaves_U16 project_ID_GUID_data_2;
  pulsewaves_U16 project_ID_GUID_data_3;
  pulsewaves_U8 project_ID_GUID_data_4[8];
  pulsewaves_CHAR system_identifier[32];
  pulsewaves_CHAR generating_software[32];
  pulsewaves_U16 file_creation_day;
  pulsewaves_U16 file_creation_year;
  pulsewaves_I64 number_of_pulses;
  pulsewaves_F32 temperature;      // [degree centigrade]
  pulsewaves_F32 pressure;         // [bar]
  pulsewaves_F32 humidity;         // [percent]
} pulsewaves_header_struct;


typedef struct pulsewaves_pulsedescription
{
  pulsewaves_U32 version;
  pulsewaves_I32 optical_center_to_anchor_point; // [sampling units]
  pulsewaves_U16 number_of_extra_waves_bytes;
  pulsewaves_U16 number_of_samplings;
  pulsewaves_F32 sample_units;                   // [nanoseconds]
  pulsewaves_U32 compression;
  pulsewaves_U32 scanner_id;
  pulsewaves_F32 wavelength;                     // [nanometer]
  pulsewaves_F32 outgoing_pulse_width;           // [nanoseconds]
  pulsewaves_F32 beam_diameter_at_exit_aperture; // [millimeters]
  pulsewaves_F32 beam_divergance;                // [milliradians]
//  pulsewaves_F32 minimal_range;                  // [meters]
//  pulsewaves_F32 maximal_range;                  // [meters]
  pulsewaves_U32 reserved;
  pulsewaves_CHAR description[32];
} pulsewaves_pulsedescription_struct;

typedef struct pulsewaves_pulsesampling
{
  pulsewaves_U32 version;
  pulsewaves_U8 type;
  pulsewaves_U8 channel;
  pulsewaves_U8 bits_for_distance_from_anchor;
  pulsewaves_U8 decimal_digits_for_distance;
  pulsewaves_U8 bits_for_number_of_segments;
  pulsewaves_U8 bits_for_number_of_samples;
  pulsewaves_U16 number_of_segments;
  pulsewaves_U32 number_of_samples;
  pulsewaves_U16 bits_per_sample;
  pulsewaves_F32 sample_units;                   // [nanoseconds]
  pulsewaves_F64 digitizer_gain;                 // [Volt]
  pulsewaves_F64 digitizer_offset;               // [Volt]
  pulsewaves_CHAR description[32];
} pulsewaves_pulsesampling_struct;

typedef struct pulsewaves_pulse
{
  pulsewaves_I64 T;
  pulsewaves_F64 anchor[3];
  pulsewaves_F64 dir[3];
  pulsewaves_U16 first_returning_sample;
  pulsewaves_U16 last_returning_sample;
  pulsewaves_U16 descriptor_index;
  pulsewaves_U16 edge_of_scan_line;
  pulsewaves_U16 scan_direction;
  pulsewaves_U16 mirror_facet;
  pulsewaves_U8 intensity;
  pulsewaves_U8 classification;
} pulsewaves_pulse_struct;

typedef struct pulsewaves_wavessampling
{
  pulsewaves_I32 num_segments;
  pulsewaves_I32* num_samples;
  pulsewaves_F32* distances;
  pulsewaves_U8** samples;
} pulsewaves_wavessampling_struct;

/*---------------------------------------------------------------------------*/
PULSEWAVES_API pulsewaves_I32
pulsewaves_get_version
(
    pulsewaves_U8*                         version_major
    , pulsewaves_U8*                       version_minor
    , pulsewaves_U16*                      version_revision
    , pulsewaves_U32*                      version_build
);

/*---------------------------------------------------------------------------*/
PULSEWAVES_API pulsewaves_I32
pulsewaves_create(
    pulsewaves_POINTER*                    pointer
);

/*---------------------------------------------------------------------------*/
PULSEWAVES_API pulsewaves_I32
pulsewaves_get_error
(
    pulsewaves_POINTER                     pointer
    , pulsewaves_CHAR**                    error
);

/*---------------------------------------------------------------------------*/
PULSEWAVES_API pulsewaves_I32
pulsewaves_header_set(
    pulsewaves_POINTER                     pointer
    , pulsewaves_header_struct*            header
);

/*---------------------------------------------------------------------------*/
PULSEWAVES_API pulsewaves_I32
pulsewaves_header_add_pulsedescriptor(
    pulsewaves_POINTER                     pointer
    , pulsewaves_pulsedescription_struct*  descriptor
    , pulsewaves_pulsesampling_struct*     samplings
);

/*---------------------------------------------------------------------------*/
PULSEWAVES_API pulsewaves_I32
pulsewaves_writer_open(
    pulsewaves_POINTER                     pointer
    , pulsewaves_CHAR*                     file_name
    , pulsewaves_BOOL                      compress
    );

/*---------------------------------------------------------------------------*/
PULSEWAVES_API pulsewaves_I32
pulsewaves_writer_write_pulse(
    pulsewaves_POINTER                     pointer
    , pulsewaves_pulse_struct*             pulse
);

/*---------------------------------------------------------------------------*/
PULSEWAVES_API pulsewaves_I32
pulsewaves_writer_write_waves(
    pulsewaves_POINTER                     pointer
    , pulsewaves_wavessampling_struct*     wavessamplings
    , pulsewaves_U32                       number_of_wavessamplings
);

/*---------------------------------------------------------------------------*/
PULSEWAVES_API pulsewaves_I32
pulsewaves_writer_close(
    pulsewaves_POINTER                     pointer
);

/*---------------------------------------------------------------------------*/
PULSEWAVES_API pulsewaves_I32
pulsewaves_destroy(
    pulsewaves_POINTER                     pointer
);

/*---------------------------------------------------------------------------*/
PULSEWAVES_API pulsewaves_I32
pulsewaves_load_dll
(
);
/*---------------------------------------------------------------------------*/

#ifdef __cplusplus
}
#endif

#endif /* PULSEWAVES_DLL_H */
