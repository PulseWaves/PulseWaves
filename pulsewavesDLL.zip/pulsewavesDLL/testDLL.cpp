/*
===============================================================================

  FILE:  testDLL.cpp
  
  CONTENTS:
  
    This is a test program for the pulsewaves DLL.

  PROGRAMMERS:
  
    martin.isenburg@gmail.com  -  http://rapidlasso.com
  
  COPYRIGHT:
  
    (c) 2007-2012, martin isenburg, rapidlasso - fast tools to catch reality

    This software is distributed WITHOUT ANY WARRANTY and without even the
    implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  
  CHANGE HISTORY:
  
    6 September 2012 -- created in the RailJet 260 between Vienna and Munich
  
===============================================================================
*/

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "pulsewaves_dll.h"

void usage(bool wait=false)
{
  fprintf(stderr,"usage:\n");
  fprintf(stderr,"testDLL -h\n");
  fprintf(stderr,"testDLL -v\n");
  fprintf(stderr,"testDLL -compress\n");
  if (wait)
  {
    fprintf(stderr,"<press ENTER>\n");
    getc(stdin);
  }
  exit(1);
}

static void byebye(bool error=false, bool wait=false)
{
  if (wait)
  {
    fprintf(stderr,"<press ENTER>\n");
    getc(stdin);
  }
  exit(error);
}

static double taketime()
{
  return (double)(clock())/CLOCKS_PER_SEC;
}

int main(int argc, char *argv[])
{
  int i;
  bool verbose = false;
  bool compress = false;
  const char* file_name = "test.pls";

  // load pulsewaves DLL

  if (pulsewaves_load_dll())
  {
    fprintf(stderr,"ERROR: loading pulsewaves DLL\n");
    byebye(argc==1);
  }

  // get version of pulsewaves DLL

  pulsewaves_U8 version_major;
  pulsewaves_U8 version_minor;
  pulsewaves_U16 version_revision;
  pulsewaves_U32 version_build;

  if (pulsewaves_get_version(&version_major, &version_minor, &version_revision, &version_build))
  {
    fprintf(stderr,"ERROR: reading pulsewaves DLL version number\n");
    byebye(argc==1);
  }

  for (i = 1; i < argc; i++)
  {
    if (strcmp(argv[i],"-h") == 0 || strcmp(argv[i],"-help") == 0)
    {
      fprintf(stderr, "testDLL of PULSEtools (by martin.isenburg@gmail.com) version: %d.%d r%d (build %d)\n", version_major, version_minor, version_revision, version_build);
      usage();
    }
    else if (strcmp(argv[i],"-version") == 0)
    {
      fprintf(stderr, "testDLL of PULSEtools (by martin.isenburg@gmail.com) version: %d.%d r%d (build %d)\n", version_major, version_minor, version_revision, version_build);
      byebye();
    }
    else if (strcmp(argv[i],"-v") == 0 || strcmp(argv[i],"-verbose") == 0)
    {
      verbose = true;
    }
    else if (strcmp(argv[i],"-compress") == 0)
    {
      compress = true;
    }
    else
    {
      fprintf(stderr, "ERROR: cannot understand argument '%s'\n", argv[i]);
      usage();
    }
  }

  if (verbose)
  {
    fprintf(stderr,"pulsewaves DLL version: %d.%d r%d (build %d)\n", version_major, version_minor, version_revision, version_build);
    if (compress)
      fprintf(stderr,"writing to test.pls & test.wvz\n");
    else
      fprintf(stderr,"writing to test.pls & test.wvs\n");
  }

  // create object in pulsewaves DLL

  pulsewaves_POINTER pulsewaves;
  if (pulsewaves_create(&pulsewaves))
  {
    fprintf(stderr,"ERROR: creating pulsewaves object\n");
    byebye(argc==1);
  }

  // populate header

  pulsewaves_header header;
  memset(&header, 0, sizeof(pulsewaves_header));

  header.scan_ID = 4711;
  sprintf(header.system_identifier, "testDLL prototype tester");
  sprintf(header.generating_software, "version %d.%dr%d (%d)",0,0,0,0);
  header.file_creation_day = 111;
  header.file_creation_year = 2012;
  header.number_of_pulses = 12;
  header.temperature = 2.3f; // [degree centigrade]
  header.pressure = 61.3f;   // [bar]
  header.humidity = 71.3f;   // [percent]

  // set the header

  if (pulsewaves_header_set(pulsewaves, &header))
  {
    fprintf(stderr,"ERROR: setting pulsewaves header\n");
    byebye(argc==1);
  }

  // create four pulsedescriptors

  pulsewaves_pulsedescription_struct pulsedescription;
  pulsewaves_pulsesampling_struct pulsesamplings[3];

  // create 1st pulsedescriptor for pulses without returning waveform

  pulsedescription.optical_center_to_anchor_point = 0;   // the distance between optical center and anchor point is zero
  pulsedescription.number_of_extra_waves_bytes = 0; 
  pulsedescription.number_of_samplings = 1;               // one outgoing only, none returning
  pulsedescription.sample_units = 1.0f;                   // [nanoseconds]
  pulsedescription.scanner_id = 0;
  pulsedescription.wavelength = 1064.0f;                  // [nanometer]
  pulsedescription.outgoing_pulse_width = 10.0f;          // [nanoseconds]
  pulsedescription.beam_diameter_at_exit_aperture = 1.2f; // [millimeters]
  pulsedescription.beam_divergance = 0.5f;                // [milliradians]
  memset(pulsedescription.description, 0, 32);
  strncpy(pulsedescription.description, "only outgoing, no returning", 32);
  pulsedescription.description[31] = '\0';

  pulsesamplings[0].type = PULSEWAVES_OUTGOING;
  pulsesamplings[0].channel = 0;
  pulsesamplings[0].bits_for_distance_from_anchor = 0;    // the anchor point is the optical center. this is when the outgoing waveform starts.
  pulsesamplings[0].decimal_digits_for_distance = 0;
  pulsesamplings[0].bits_for_number_of_segments = 0;      // the number of segments is fixed (i.e. there is just one)
  pulsesamplings[0].bits_for_number_of_samples = 0;       // the number of samples is fixed (i.e. it is always 24)
  pulsesamplings[0].number_of_segments = 1;               // the number of segments per sampling is always 1
  pulsesamplings[0].number_of_samples = 24;               // the number of samples per segment is always 24
  pulsesamplings[0].bits_per_sample = 8;                  // the number of bits per sample is always 8
  pulsesamplings[0].sample_units = 1.0f;                  // [nanoseconds]
  pulsesamplings[0].digitizer_gain = 0.0172906f;          // [volt]
  pulsesamplings[0].digitizer_offset = 0.0f;              // [volt]
  memset(pulsesamplings[0].description, 0, 32);
  strncpy(pulsesamplings[0].description, "outgoing, 24 samples, 8 bits", 32);
  pulsesamplings[0].description[31] = '\0';

  // add 1st pulsedescriptor to the header (it will have index 0)

  if (pulsewaves_header_add_pulsedescriptor(pulsewaves, &pulsedescription, pulsesamplings))
  {
    fprintf(stderr,"ERROR: adding 1st pulsedescriptor to header\n");
    byebye(argc==1);
  }

  // create 2nd pulsedescriptor for pulses with one returning waveform composed of one low segment with varying sample number

  pulsedescription.optical_center_to_anchor_point = 0;    // the distance between optical center and anchor point is zero
  pulsedescription.number_of_extra_waves_bytes = 0; 
  pulsedescription.number_of_samplings = 2;               // one outgoing, one returning (with one low segment)
  pulsedescription.sample_units = 1.0f;                   // [nanoseconds]
  pulsedescription.scanner_id = 0;
  pulsedescription.wavelength = 1064.0f;                  // [nanometer]
  pulsedescription.outgoing_pulse_width = 10.0f;          // [nanoseconds]
  pulsedescription.beam_diameter_at_exit_aperture = 1.2f; // [millimeters]
  pulsedescription.beam_divergance = 0.5f;                // [milliradians]
  memset(pulsedescription.description, 0, 32);
  strncpy(pulsedescription.description, "out + return, 1 low seg, vary", 32);
  pulsedescription.description[31] = '\0';

  pulsesamplings[1].type = PULSEWAVES_RETURNING;
  pulsesamplings[1].channel = 0;
  pulsesamplings[1].bits_for_distance_from_anchor = 32;   // the distance of the returning waveform is specified per segment with 16 bits in sampling units
  pulsesamplings[1].decimal_digits_for_distance = 1;      // the distance is specified in increments of 0.1 * sampling unit 
  pulsesamplings[1].bits_for_number_of_segments = 0;      // the number of segments is fixed (i.e. there is just one)
  pulsesamplings[1].bits_for_number_of_samples = 8;       // the number of samples per segment is specified per segment with 8 bits
  pulsesamplings[1].number_of_segments = 1;               // the number of segments per sampling is always 1
  pulsesamplings[1].number_of_samples = 0;                // the number of samples per segment varies
  pulsesamplings[1].bits_per_sample = 8;                  // the number of bits per sample is always 8
  pulsesamplings[1].sample_units = 1;                     // [nanoseconds]
  pulsesamplings[1].digitizer_gain = 0.0172906f;          // [volt]
  pulsesamplings[1].digitizer_offset = 0.0;               // [volt]
  memset(pulsesamplings[1].description, 0, 32);
  strncpy(pulsesamplings[1].description, "return, 1 low, vary, 8 bits", 32);
  pulsesamplings[1].description[31] = '\0';

  // add 2nd pulsedescriptor to the header (it will have index 1)

  if (pulsewaves_header_add_pulsedescriptor(pulsewaves, &pulsedescription, pulsesamplings))
  {
    fprintf(stderr,"ERROR: adding 2nd pulsedescriptor to header\n");
    byebye(argc==1);
  }

  // create 3rd pulsedescriptor for pulses with one returning waveform composed of two low segments with varying sample number

  pulsedescription.optical_center_to_anchor_point = 0;    // the distance between optical center and anchor point is zero
  pulsedescription.number_of_extra_waves_bytes = 0; 
  pulsedescription.number_of_samplings = 2;               // one outgoing, one returning (with two low segments)
  pulsedescription.sample_units = 1.0f;                   // [nanoseconds]
  pulsedescription.scanner_id = 0;
  pulsedescription.wavelength = 1064.0f;                  // [nanometer]
  pulsedescription.outgoing_pulse_width = 10.0f;          // [nanoseconds]
  pulsedescription.beam_diameter_at_exit_aperture = 1.2f; // [millimeters]
  pulsedescription.beam_divergance = 0.5f;                // [milliradians]
  memset(pulsedescription.description, 0, 32);
  strncpy(pulsedescription.description, "out + return, 2 low seg, vary", 32);
  pulsedescription.description[31] = '\0';

  pulsesamplings[1].type = PULSEWAVES_RETURNING;
  pulsesamplings[1].channel = 0;
  pulsesamplings[1].bits_for_distance_from_anchor = 32;   // the distance of the returning waveform is specified per segment with 16 bits in sampling units
  pulsesamplings[1].decimal_digits_for_distance = 1;      // the distance is specified in increments of 0.1 * sampling unit 
  pulsesamplings[1].bits_for_number_of_segments = 0;      // the number of segments is fixed (i.e. there are exactly two)
  pulsesamplings[1].bits_for_number_of_samples = 8;       // the number of samples per segment is specified per segment with 8 bits
  pulsesamplings[1].number_of_segments = 2;               // the number of segments per sampling is always 2
  pulsesamplings[1].number_of_samples = 0;                // the number of samples per segment varies
  pulsesamplings[1].bits_per_sample = 8;                  // the number of bits per sample is always 8
  pulsesamplings[1].sample_units = 1;                     // [nanoseconds]
  pulsesamplings[1].digitizer_gain = 0.0172906f;          // [volt]
  pulsesamplings[1].digitizer_offset = 0.0;               // [volt]
  memset(pulsesamplings[1].description, 0, 32);
  strncpy(pulsesamplings[1].description, "return, 2 low, vary, 8 bits", 32);
  pulsesamplings[1].description[31] = '\0';

  // add 3rd pulsedescriptor to the header (it will have index 2)

  if (pulsewaves_header_add_pulsedescriptor(pulsewaves, &pulsedescription, pulsesamplings))
  {
    fprintf(stderr,"ERROR: adding 3rd pulsedescriptor to header\n");
    byebye(argc==1);
  }

  // create 4th pulsedescriptor for pulses with one returning waveform composed of three low segments with varying sample number

  pulsedescription.optical_center_to_anchor_point = 0;    // the distance between optical center and anchor point is zero
  pulsedescription.number_of_extra_waves_bytes = 0; 
  pulsedescription.number_of_samplings = 2;               // one outgoing, one returning (with three low segments)
  pulsedescription.sample_units = 1.0f;                   // [nanoseconds]
  pulsedescription.scanner_id = 0;
  pulsedescription.wavelength = 1064.0f;                  // [nanometer]
  pulsedescription.outgoing_pulse_width = 10.0f;          // [nanoseconds]
  pulsedescription.beam_diameter_at_exit_aperture = 1.2f; // [millimeters]
  pulsedescription.beam_divergance = 0.5f;                // [milliradians]
  memset(pulsedescription.description, 0, 32);
  strncpy(pulsedescription.description, "out + return, 3 low seg, vary", 32);
  pulsedescription.description[31] = '\0';

  pulsesamplings[1].type = PULSEWAVES_RETURNING;
  pulsesamplings[1].channel = 0;
  pulsesamplings[1].bits_for_distance_from_anchor = 32;   // the distance of the returning waveform is specified per segment with 16 bits in sampling units
  pulsesamplings[1].decimal_digits_for_distance = 1;      // the distance is specified in increments of 0.1 * sampling unit 
  pulsesamplings[1].bits_for_number_of_segments = 0;      // the number of segments is fixed (i.e. there are exactly three)
  pulsesamplings[1].bits_for_number_of_samples = 8;       // the number of samples per segment is specified per segment with 8 bits
  pulsesamplings[1].number_of_segments = 3;               // the number of segments per sampling is always 3
  pulsesamplings[1].number_of_samples = 0;                // the number of samples per segment varies
  pulsesamplings[1].bits_per_sample = 8;                  // the number of bits per sample is always 8
  pulsesamplings[1].sample_units = 1;                     // [nanoseconds]
  pulsesamplings[1].digitizer_gain = 0.0172906f;          // [volt]
  pulsesamplings[1].digitizer_offset = 0.0;               // [volt]
  memset(pulsesamplings[1].description, 0, 32);
  strncpy(pulsesamplings[1].description, "return, 3 low, vary, 8 bits", 32);
  pulsesamplings[1].description[31] = '\0';

  // add 4th pulsedescriptor to the header (it will have index 3)

  if (pulsewaves_header_add_pulsedescriptor(pulsewaves, &pulsedescription, pulsesamplings))
  {
    fprintf(stderr,"ERROR: adding 4th pulsedescriptor to header\n");
    byebye(argc==1);
  }

  // create 5th pulsedescriptor for pulses with one returning waveform composed of one high segment with varying sample number
  
  pulsedescription.optical_center_to_anchor_point = 0;    // the distance between optical center and anchor point is zero
  pulsedescription.number_of_extra_waves_bytes = 0; 
  pulsedescription.number_of_samplings = 2;               // one outgoing, one returning (with one high segment)
  pulsedescription.sample_units = 1.0f;                   // [nanoseconds]
  pulsedescription.scanner_id = 0;
  pulsedescription.wavelength = 1064.0f;                  // [nanometer]
  pulsedescription.outgoing_pulse_width = 10.0f;          // [nanoseconds]
  pulsedescription.beam_diameter_at_exit_aperture = 1.2f; // [millimeters]
  pulsedescription.beam_divergance = 0.5f;                // [milliradians]
  memset(pulsedescription.description, 0, 32);
  strncpy(pulsedescription.description, "out + return, 1 high seg, vary", 32);
  pulsedescription.description[31] = '\0';

  pulsesamplings[1].type = PULSEWAVES_RETURNING;
  pulsesamplings[1].channel = 1;
  pulsesamplings[1].bits_for_distance_from_anchor = 32;   // the distance of the returning waveform is specified per segment with 16 bits in sampling units
  pulsesamplings[1].decimal_digits_for_distance = 1;      // the distance is specified in increments of 0.1 * sampling unit 
  pulsesamplings[1].bits_for_number_of_segments = 0;      // the number of segments is fixed (i.e. there is exactly one)
  pulsesamplings[1].bits_for_number_of_samples = 8;       // the number of samples per segment is specified per segment with 8 bits
  pulsesamplings[1].number_of_segments = 1;               // the number of segments per sampling is always 1
  pulsesamplings[1].number_of_samples = 0;                // the number of samples per segment varies
  pulsesamplings[1].bits_per_sample = 8;                  // the number of bits per sample is always 8
  pulsesamplings[1].sample_units = 1;                     // [nanoseconds]
  pulsesamplings[1].digitizer_gain = 4.4263936f;          // [volt]
  pulsesamplings[1].digitizer_offset = 0.0;               // [volt]
  memset(pulsesamplings[1].description, 0, 32);
  strncpy(pulsesamplings[1].description, "return, 1 high, vary, 8 bits", 32);
  pulsesamplings[1].description[31] = '\0';

  // add 5th pulsedescriptor to the header (it will have index 4)

  if (pulsewaves_header_add_pulsedescriptor(pulsewaves, &pulsedescription, pulsesamplings))
  {
    fprintf(stderr,"ERROR: adding 5th pulsedescriptor to header\n");
    byebye(argc==1);
  }
  
  // create 6th pulsedescriptor for pulses with one returning waveform composed of one low segment and one high segment with varying sample number

  pulsedescription.optical_center_to_anchor_point = 0;    // the distance between optical center and anchor point is zero
  pulsedescription.number_of_extra_waves_bytes = 0; 
  pulsedescription.number_of_samplings = 3;               // one outgoing, two returning (one with one low segment, one with one high segment)
  pulsedescription.sample_units = 1.0f;                   // [nanoseconds]
  pulsedescription.scanner_id = 0;
  pulsedescription.wavelength = 1064.0f;                  // [nanometer]
  pulsedescription.outgoing_pulse_width = 10.0f;          // [nanoseconds]
  pulsedescription.beam_diameter_at_exit_aperture = 1.2f; // [millimeters]
  pulsedescription.beam_divergance = 0.5f;                // [milliradians]
  memset(pulsedescription.description, 0, 32);
  strncpy(pulsedescription.description, "out + return, 1 lo, 1 hi, vary", 32);
  pulsedescription.description[31] = '\0';

  pulsesamplings[1].type = PULSEWAVES_RETURNING;
  pulsesamplings[1].channel = 0;
  pulsesamplings[1].bits_for_distance_from_anchor = 32;   // the distance of the returning waveform is specified per segment with 16 bits in sampling units
  pulsesamplings[1].decimal_digits_for_distance = 1;      // the distance is specified in increments of 0.1 * sampling unit 
  pulsesamplings[1].bits_for_number_of_segments = 0;      // the number of segments is fixed (i.e. there is just one)
  pulsesamplings[1].bits_for_number_of_samples = 8;       // the number of samples per segment is specified per segment with 8 bits
  pulsesamplings[1].number_of_segments = 1;               // the number of segments per sampling is always 1
  pulsesamplings[1].number_of_samples = 0;                // the number of samples per segment varies
  pulsesamplings[1].bits_per_sample = 8;                  // the number of bits per sample is always 8
  pulsesamplings[1].sample_units = 1;                     // [nanoseconds]
  pulsesamplings[1].digitizer_gain = 0.0172906f;          // [volt]
  pulsesamplings[1].digitizer_offset = 0.0;               // [volt]
  memset(pulsesamplings[1].description, 0, 32);
  strncpy(pulsesamplings[1].description, "return, 1 low, vary, 8 bits", 32);
  pulsesamplings[1].description[31] = '\0';

  pulsesamplings[2].type = PULSEWAVES_RETURNING;
  pulsesamplings[2].channel = 1;
  pulsesamplings[2].bits_for_distance_from_anchor = 32;   // the distance of the returning waveform is specified per segment with 16 bits in sampling units
  pulsesamplings[2].decimal_digits_for_distance = 1;      // the distance is specified in increments of 0.1 * sampling unit 
  pulsesamplings[2].bits_for_number_of_segments = 0;      // the number of segments is fixed (i.e. there is exactly one)
  pulsesamplings[2].bits_for_number_of_samples = 8;       // the number of samples per segment is specified per segment with 8 bits
  pulsesamplings[2].number_of_segments = 1;               // the number of segments per sampling is always 1
  pulsesamplings[2].number_of_samples = 0;                // the number of samples per segment varies
  pulsesamplings[2].bits_per_sample = 8;                  // the number of bits per sample is always 8
  pulsesamplings[2].sample_units = 1;                     // [nanoseconds]
  pulsesamplings[2].digitizer_gain = 4.4263936f;          // [volt]
  pulsesamplings[2].digitizer_offset = 0.0;               // [volt]
  memset(pulsesamplings[2].description, 0, 32);
  strncpy(pulsesamplings[2].description, "return, 1 high, vary, 8 bits", 32);
  pulsesamplings[2].description[31] = '\0';

  // add 6th pulsedescriptor to the header (it will have index 5)

  if (pulsewaves_header_add_pulsedescriptor(pulsewaves, &pulsedescription, pulsesamplings))
  {
    fprintf(stderr,"ERROR: adding 6th pulsedescriptor to header\n");
    byebye(argc==1);
  }

  // create 7th pulsedescriptor for pulses with one returning waveform composed of two low segments and one high segment with varying sample number

  pulsedescription.optical_center_to_anchor_point = 0;    // the distance between optical center and anchor point is zero
  pulsedescription.number_of_extra_waves_bytes = 0; 
  pulsedescription.number_of_samplings = 3;               // one outgoing, two returning (one with two low segments, one with one high segment)
  pulsedescription.sample_units = 1.0f;                   // [nanoseconds]
  pulsedescription.scanner_id = 0;
  pulsedescription.wavelength = 1064.0f;                  // [nanometer]
  pulsedescription.outgoing_pulse_width = 10.0f;          // [nanoseconds]
  pulsedescription.beam_diameter_at_exit_aperture = 1.2f; // [millimeters]
  pulsedescription.beam_divergance = 0.5f;                // [milliradians]
  memset(pulsedescription.description, 0, 32);
  strncpy(pulsedescription.description, "out + return, 2 lo, 1 hi, vary", 32);
  pulsedescription.description[31] = '\0';

  pulsesamplings[1].type = PULSEWAVES_RETURNING;
  pulsesamplings[1].channel = 0;
  pulsesamplings[1].bits_for_distance_from_anchor = 32;   // the distance of the returning waveform is specified per segment with 16 bits in sampling units
  pulsesamplings[1].decimal_digits_for_distance = 1;      // the distance is specified in increments of 0.1 * sampling unit 
  pulsesamplings[1].bits_for_number_of_segments = 0;      // the number of segments is fixed (i.e. there are exactly two)
  pulsesamplings[1].bits_for_number_of_samples = 8;       // the number of samples per segment is specified per segment with 8 bits
  pulsesamplings[1].number_of_segments = 2;               // the number of segments per sampling is always 2
  pulsesamplings[1].number_of_samples = 0;                // the number of samples per segment varies
  pulsesamplings[1].bits_per_sample = 8;                  // the number of bits per sample is always 8
  pulsesamplings[1].sample_units = 1;                     // [nanoseconds]
  pulsesamplings[1].digitizer_gain = 0.0172906f;          // [volt]
  pulsesamplings[1].digitizer_offset = 0.0;               // [volt]
  memset(pulsesamplings[1].description, 0, 32);
  strncpy(pulsesamplings[1].description, "return, 2 low, vary, 8 bits", 32);
  pulsesamplings[1].description[31] = '\0';  
  
  pulsesamplings[2].type = PULSEWAVES_RETURNING;
  pulsesamplings[2].channel = 1;
  pulsesamplings[2].bits_for_distance_from_anchor = 32;   // the distance of the returning waveform is specified per segment with 16 bits in sampling units
  pulsesamplings[2].decimal_digits_for_distance = 1;      // the distance is specified in increments of 0.1 * sampling unit 
  pulsesamplings[2].bits_for_number_of_segments = 0;      // the number of segments is fixed (i.e. there is exactly one)
  pulsesamplings[2].bits_for_number_of_samples = 8;       // the number of samples per segment is specified per segment with 8 bits
  pulsesamplings[2].number_of_segments = 1;               // the number of segments per sampling is always 1
  pulsesamplings[2].number_of_samples = 0;                // the number of samples per segment varies
  pulsesamplings[2].bits_per_sample = 8;                  // the number of bits per sample is always 8
  pulsesamplings[2].sample_units = 1;                     // [nanoseconds]
  pulsesamplings[2].digitizer_gain = 4.4263936f;          // [volt]
  pulsesamplings[2].digitizer_offset = 0.0;               // [volt]
  memset(pulsesamplings[2].description, 0, 32);
  strncpy(pulsesamplings[2].description, "return, 1 high, vary, 8 bits", 32);
  pulsesamplings[2].description[31] = '\0';

  // add 7th pulsedescriptor to the header (it will have index 6)

  if (pulsewaves_header_add_pulsedescriptor(pulsewaves, &pulsedescription, pulsesamplings))
  {
    fprintf(stderr,"ERROR: adding 7th pulsedescriptor to header\n");
    byebye(argc==1);
  }
  
  // create 8th pulsedescriptor for pulses with one returning waveform composed of three low segments and one high segment with varying sample number

  pulsedescription.optical_center_to_anchor_point = 0;    // the distance between optical center and anchor point is zero
  pulsedescription.number_of_extra_waves_bytes = 0; 
  pulsedescription.number_of_samplings = 3;               // one outgoing, two returning (one with three low segments, one with one high segment)
  pulsedescription.sample_units = 1.0f;                   // [nanoseconds]
  pulsedescription.scanner_id = 0;
  pulsedescription.wavelength = 1064.0f;                  // [nanometer]
  pulsedescription.outgoing_pulse_width = 10.0f;          // [nanoseconds]
  pulsedescription.beam_diameter_at_exit_aperture = 1.2f; // [millimeters]
  pulsedescription.beam_divergance = 0.5f;                // [milliradians]
  memset(pulsedescription.description, 0, 32);
  strncpy(pulsedescription.description, "out + return, 3 lo, 1 hi, vary", 32);
  pulsedescription.description[31] = '\0';

  pulsesamplings[1].type = PULSEWAVES_RETURNING;
  pulsesamplings[1].channel = 0;
  pulsesamplings[1].bits_for_distance_from_anchor = 32;   // the distance of the returning waveform is specified per segment with 16 bits in sampling units
  pulsesamplings[1].decimal_digits_for_distance = 1;      // the distance is specified in increments of 0.1 * sampling unit 
  pulsesamplings[1].bits_for_number_of_segments = 0;      // the number of segments is fixed (i.e. there are exactly three)
  pulsesamplings[1].bits_for_number_of_samples = 8;       // the number of samples per segment is specified per segment with 8 bits
  pulsesamplings[1].number_of_segments = 3;               // the number of segments per sampling is always 3
  pulsesamplings[1].number_of_samples = 0;                // the number of samples per segment varies
  pulsesamplings[1].bits_per_sample = 8;                  // the number of bits per sample is always 8
  pulsesamplings[1].sample_units = 1;                     // [nanoseconds]
  pulsesamplings[1].digitizer_gain = 0.0172906f;          // [volt]
  pulsesamplings[1].digitizer_offset = 0.0;               // [volt]
  memset(pulsesamplings[1].description, 0, 32);
  strncpy(pulsesamplings[1].description, "return, 3 low, vary, 8 bits", 32);
  pulsesamplings[1].description[31] = '\0';

  pulsesamplings[2].type = PULSEWAVES_RETURNING;
  pulsesamplings[2].channel = 1;
  pulsesamplings[2].bits_for_distance_from_anchor = 32;   // the distance of the returning waveform is specified per segment with 16 bits in sampling units
  pulsesamplings[2].decimal_digits_for_distance = 1;      // the distance is specified in increments of 0.1 * sampling unit 
  pulsesamplings[2].bits_for_number_of_segments = 0;      // the number of segments is fixed (i.e. there is exactly one)
  pulsesamplings[2].bits_for_number_of_samples = 8;       // the number of samples per segment is specified per segment with 8 bits
  pulsesamplings[2].number_of_segments = 1;               // the number of segments per sampling is always 1
  pulsesamplings[2].number_of_samples = 0;                // the number of samples per segment varies
  pulsesamplings[2].bits_per_sample = 8;                  // the number of bits per sample is always 8
  pulsesamplings[2].sample_units = 1;                     // [nanoseconds]
  pulsesamplings[2].digitizer_gain = 4.4263936f;          // [volt]
  pulsesamplings[2].digitizer_offset = 0.0;               // [volt]
  memset(pulsesamplings[2].description, 0, 32);
  strncpy(pulsesamplings[2].description, "return, 1 high, vary, 8 bits", 32);
  pulsesamplings[2].description[31] = '\0';

  // add 8th pulsedescriptor to the header (it will have index 7)

  if (pulsewaves_header_add_pulsedescriptor(pulsewaves, &pulsedescription, pulsesamplings))
  {
    fprintf(stderr,"ERROR: adding 8th pulsedescriptor to header\n");
    byebye(argc==1);
  }

  // create 9th pulsedescriptor for pulses with one returning waveform composed of s_low low segments and s_high high segments with varying sample number

  pulsedescription.optical_center_to_anchor_point = 0;    // the distance between optical center and anchor point is zero
  pulsedescription.number_of_extra_waves_bytes = 0; 
  pulsedescription.number_of_samplings = 3;               // one outgoing, two returning (one with three low segments, one with one high segment)
  pulsedescription.sample_units = 1.0f;                   // [nanoseconds]
  pulsedescription.scanner_id = 0;
  pulsedescription.wavelength = 1064.0f;                  // [nanometer]
  pulsedescription.outgoing_pulse_width = 10.0f;          // [nanoseconds]
  pulsedescription.beam_diameter_at_exit_aperture = 1.2f; // [millimeters]
  pulsedescription.beam_divergance = 0.5f;                // [milliradians]
  memset(pulsedescription.description, 0, 32);
  strncpy(pulsedescription.description, "out + return, x lo, x hi, vary", 32);
  pulsedescription.description[31] = '\0';

  pulsesamplings[1].type = PULSEWAVES_RETURNING;
  pulsesamplings[1].channel = 0;
  pulsesamplings[1].bits_for_distance_from_anchor = 32;   // the distance of the returning waveform is specified per segment with 16 bits in sampling units
  pulsesamplings[1].decimal_digits_for_distance = 1;      // the distance is specified in increments of 0.1 * sampling unit 
  pulsesamplings[1].bits_for_number_of_segments = 8;      // the number of segments in sampling is specified with 8 bits
  pulsesamplings[1].bits_for_number_of_samples = 8;       // the number of samples per segment is specified per segment with 8 bits
  pulsesamplings[1].number_of_segments = 0;               // the number of segments in sampling varies
  pulsesamplings[1].number_of_samples = 0;                // the number of samples per segment varies
  pulsesamplings[1].bits_per_sample = 8;                  // the number of bits per sample is always 8
  pulsesamplings[1].sample_units = 1;                     // [nanoseconds]
  pulsesamplings[1].digitizer_gain = 0.0172906f;          // [volt]
  pulsesamplings[1].digitizer_offset = 0.0;               // [volt]
  memset(pulsesamplings[1].description, 0, 32);
  strncpy(pulsesamplings[1].description, "return, x low, vary, 8 bits", 32);
  pulsesamplings[1].description[31] = '\0';

  pulsesamplings[2].type = PULSEWAVES_RETURNING;
  pulsesamplings[2].channel = 1;
  pulsesamplings[2].bits_for_distance_from_anchor = 32;   // the distance of the returning waveform is specified per segment with 16 bits in sampling units
  pulsesamplings[2].decimal_digits_for_distance = 1;      // the distance is specified in increments of 0.1 * sampling unit 
  pulsesamplings[2].bits_for_number_of_segments = 8;      // the number of segments in sampling is specified with 8 bits
  pulsesamplings[2].bits_for_number_of_samples = 8;       // the number of samples per segment is specified per segment with 8 bits
  pulsesamplings[2].number_of_segments = 0;               // the number of segments in sampling varies
  pulsesamplings[2].number_of_samples = 0;                // the number of samples per segment varies
  pulsesamplings[2].bits_per_sample = 8;                  // the number of bits per sample is always 8
  pulsesamplings[2].sample_units = 1;                     // [nanoseconds]
  pulsesamplings[2].digitizer_gain = 4.4263936f;          // [volt]
  pulsesamplings[2].digitizer_offset = 0.0;               // [volt]
  memset(pulsesamplings[2].description, 0, 32);
  strncpy(pulsesamplings[2].description, "return, x high, vary, 8 bits", 32);
  pulsesamplings[2].description[31] = '\0';

  // add 9th pulsedescriptor to the header (it will have index 8)

  if (pulsewaves_header_add_pulsedescriptor(pulsewaves, &pulsedescription, pulsesamplings))
  {
    fprintf(stderr,"ERROR: adding 9th pulsedescriptor to header\n");
    byebye(argc==1);
  }

  // open the writer

  if (pulsewaves_writer_open(pulsewaves, "test.pls", compress))
  {
    fprintf(stderr,"ERROR: opening pulsewaves writer\n");
    byebye(argc==1);
  }

  pulsewaves_pulse_struct pulse;

  // setup 1st pulse

  pulse.T = 129863735377; // to get Standard GPS time in seconds, scale by 1e-6 and add 1e9 seconds

  pulse.anchor[0] = 235005.689; 
  pulse.anchor[1] = 800049.976;
  pulse.anchor[2] = 1261.177; 
  
  pulse.dir[0] = 0.0422858574893;
  pulse.dir[1] = -0.0139114190461;
  pulse.dir[2] = -0.143093129736;

  pulse.first_returning_sample = 8213;
  pulse.last_returning_sample = 8251;
  pulse.descriptor_index = 1; // outgoing + returning (one low segment)
  pulse.edge_of_scan_line = 0;
  pulse.scan_direction = 0;
  pulse.mirror_facet = 2;
  pulse.intensity = 0;
  pulse.classification = 0;

  // write 1st pulse

  if (pulsewaves_writer_write_pulse(pulsewaves, &pulse))
  {
    fprintf(stderr,"ERROR: writing 1st pulse\n");
    byebye(argc==1);
  }

  // setup 1st waves

  pulsewaves_wavessampling wavessampling1[2];

  // setup 1st wavessampling[0] (outgoing, 1 segment, 24 samples, 8 bits)

  pulsewaves_I32 outgoing1_num_samples[1] = { 24 };
  pulsewaves_F32 outgoing1_distances[1] = { 0.0f };
  pulsewaves_U8 outgoing1_samples_segment0[24] = { 2,2,2,2,3,9,19,34,57,91,143,167,127,82,55,23,9,6,3,2,2,2,2,2 } ;
  pulsewaves_U8* outgoing1_samples[1];
  outgoing1_samples[0] = outgoing1_samples_segment0;

  wavessampling1[0].num_segments = 1;
  wavessampling1[0].num_samples = outgoing1_num_samples;
  wavessampling1[0].distances = outgoing1_distances;
  wavessampling1[0].samples = outgoing1_samples;

  // setup 1st wavessampling1[1] (outgoing, 1 segment, 39 samples, 8 bits)

  pulsewaves_I32 returning1_num_samples[1] = { 39 };
  pulsewaves_F32 returning1_distances[1] = { 8212.7f };
  pulsewaves_U8 returning1_samples_segment0[39] = { 2,2,2,2,2,2,2,2,2,2,2,2,5,9,22,39,57,78,101,127,138,151,120,101,88,56,43,33,21,14,9,6,4,3,2,2,2,2,2 } ;
  pulsewaves_U8* returning1_samples[1];
  returning1_samples[0] = returning1_samples_segment0;

  wavessampling1[1].num_segments = 1;
  wavessampling1[1].num_samples = returning1_num_samples;
  wavessampling1[1].distances = returning1_distances;
  wavessampling1[1].samples = returning1_samples;

  // write 1st waves

  if (pulsewaves_writer_write_waves(pulsewaves, wavessampling1, 2))
  {
    fprintf(stderr,"ERROR: writing 1st waves\n");
    byebye(argc==1);
  }

  // setup 2nd pulse

  pulse.T = 129863735407; // to get Standard GPS time in seconds, scale by 1e-6 and add 1e9 seconds

  pulse.anchor[0] = 235005.734; 
  pulse.anchor[1] = 800050.132;
  pulse.anchor[2] = 1261.178; 
  
  pulse.dir[0] = 0.0422858574893;
  pulse.dir[1] = -0.0139114190461;
  pulse.dir[2] = -0.143093129736;

  pulse.first_returning_sample = 8219;
  pulse.last_returning_sample = 8259;
  pulse.descriptor_index = 1; // outgoing + returning (one low segment)
  pulse.edge_of_scan_line = 0;
  pulse.scan_direction = 0;
  pulse.mirror_facet = 2;
  pulse.intensity = 0;
  pulse.classification = 0;

  // write 2nd pulse

  if (pulsewaves_writer_write_pulse(pulsewaves, &pulse))
  {
    fprintf(stderr,"ERROR: writing 2nd pulse\n");
    byebye(argc==1);
  }

  // setup 2nd waves

  pulsewaves_wavessampling wavessampling2[2];

  // setup 2nd wavessampling[0] (outgoing, 1 segment, 24 samples, 8 bits)

  pulsewaves_I32 outgoing2_num_samples[1] = { 24 };
  pulsewaves_F32 outgoing2_distances[1] = { 0.0f };
  pulsewaves_U8 outgoing2_samples_segment0[24] = { 2,3,9,21,34,54,94,141,165,124,80,57,24,8,5,3,2,2,2,2,2,2,2,2 } ;
  pulsewaves_U8* outgoing2_samples[1];
  outgoing2_samples[0] = outgoing2_samples_segment0;

  wavessampling2[0].num_segments = 1;
  wavessampling2[0].num_samples = outgoing2_num_samples;
  wavessampling2[0].distances = outgoing2_distances;
  wavessampling2[0].samples = outgoing2_samples;

  // setup 2nd wavessampling2[1] (outgoing, 1 segment, 41 samples, 8 bits)

  pulsewaves_I32 returning2_num_samples[1] = { 41 };
  pulsewaves_F32 returning2_distances[1] = { 8218.9f };
  pulsewaves_U8 returning2_samples_segment0[41] = { 2,2,2,5,9,22,39,57,78,101,88,128,131,128,71,85,52,48,37,29,14,9,7,6,5,4,3,2,2,2,2,2,2,2,2,2,2,2,2,2,2 } ;
  pulsewaves_U8* returning2_samples[1];
  returning2_samples[0] = returning2_samples_segment0;

  wavessampling2[1].num_segments = 1;
  wavessampling2[1].num_samples = returning2_num_samples;
  wavessampling2[1].distances = returning2_distances;
  wavessampling2[1].samples = returning2_samples;

  // write 2nd waves

  if (pulsewaves_writer_write_waves(pulsewaves, wavessampling2, 2))
  {
    fprintf(stderr,"ERROR: writing 2nd waves\n");
    byebye(argc==1);
  }

  // write line of 10 more pulses that are shifted versions of the last pulse and slowly get shorter

  for (int j = 1; j <= 10; j++)
  {
    // modify the 2nd pulse and waves

    pulse.T += 30;
    pulse.anchor[0] += 0.1f; 
    pulse.anchor[1] += 0.1f;
    pulse.last_returning_sample -= 1;
    returning2_num_samples[0] -= 1;

    // write j + 2nd pulse

    if (pulsewaves_writer_write_pulse(pulsewaves, &pulse))
    {
      fprintf(stderr,"ERROR: writing %d + 2nd pulse\n", j);
      byebye(argc==1);
    }

    // write j + 2nd waves

    if (pulsewaves_writer_write_waves(pulsewaves, wavessampling2, 2))
    {
      fprintf(stderr,"ERROR: writing %d + 2nd waves\n", j);
      byebye(argc==1);
    }
  }

  // close the writer

  if (pulsewaves_writer_close(pulsewaves))
  {
    fprintf(stderr,"ERROR: closing pulsewaves writer\n");
    byebye(argc==1);
  }

  // destroy object in pulsewaves DLL

  if (pulsewaves_destroy(pulsewaves))
  {
    fprintf(stderr,"ERROR: destroying pulsewaves object\n");
    byebye(argc==1);
  }

  return 0;
}
